// PLUGIN/BRATT.js - 100% WORKING untuk custom.js
const fetch = require("node-fetch");
const fs = require("fs");
const path = require("path");

module.exports = (bot) => {
  let enabled = true;

  bot.onText(/\/BRAT(?:@[\w]+)?(?:\s+(.+))?/, async (msg, match) => {
    if (!enabled) return;

    const chatId = msg.chat.id;
    const text = match[1];
    
    if (!text) {
      return bot.sendMessage(chatId, "⚠️ Contoh penggunaan:\n/bratt Hello World!");
    }

    try {
      const statusMsg = await bot.sendMessage(chatId, "⏳ Sedang generate stiker brat...");

      // API untuk generate brat image
      const imageUrl = `https://api-simplebot.vercel.app/imagecreator/brat?apikey=free&text=${encodeURIComponent(text)}`;
      const res = await fetch(imageUrl);
      
      if (!res.ok) {
        throw new Error('API brat gagal');
      }
      
      const buffer = await res.buffer();

      // Buat folder temp kalau belum ada
      const tempDir = path.join(__dirname, '../temp');
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }

      // Dynamic file-type (skip kalau error)
      let fileExt = 'webp';
      try {
        const { fileTypeFromBuffer } = await import("file-type");
        const fileType = await fileTypeFromBuffer(buffer);
        fileExt = fileType?.ext || 'webp';
      } catch (e) {
        console.log('file-type skip, pakai webp');
      }

      const tmpPath = path.join(tempDir, `brat-${Date.now()}.${fileExt}`);
      fs.writeFileSync(tmpPath, buffer);

      // Kirim sticker
      await bot.sendSticker(chatId, tmpPath, {
        reply_to_message_id: msg.message_id
      });

      // Cleanup
      setTimeout(() => {
        try {
          fs.unlinkSync(tmpPath);
        } catch (e) {}
      }, 5000);

      // Hapus status
      setTimeout(() => {
        bot.deleteMessage(chatId, statusMsg.message_id).catch(() => {});
      }, 3000);

    } catch (err) {
      console.error("❌ Gagal kirim stiker brat:", err.message);
      bot.sendMessage(chatId, "❌ Error pas buat stikernya bre.");
    }
  });

  return {
    enable() {
      enabled = true;
      console.log("[PLUGIN] Bratt Sticker diaktifkan");
    },
    disable() {
      enabled = false;
      console.log("[PLUGIN] Bratt Sticker dimatikan");
    }
  };
};
