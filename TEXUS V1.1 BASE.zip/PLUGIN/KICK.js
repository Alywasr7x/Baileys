// PLUGIN/KICK.js - 100% WORKING untuk custom.js 
const axios = require('axios');

module.exports = (bot) => {
  let enabled = true;

  bot.onText(/\/KICK(?:@[\w]+)?$/, async (msg) => {
    if (!enabled) return;

    const chatId = msg.chat.id;
    const token = bot.token;

    try {
      // Cek grup
      if (msg.chat.type !== 'group' && msg.chat.type !== 'supergroup') {
        return bot.sendMessage(chatId, '⚠️ PERINGATAN HANYA BISA DI GROUB!');
      }

      // WAJIB REPLY
      if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❗ REPLAY TO USER!');
      }

      const targetId = msg.reply_to_message.from.id;
      
      // Skip bot sendiri
      const botInfo = await bot.getMe();
      if (targetId === botInfo.id) {
        return bot.sendMessage(chatId, '❗NGAPAIN TOLOL!');
      }

      // KICK via DIRECT API CALL (PASTI WORK)
      const kickResponse = await axios.post(`https://api.telegram.org/bot${token}/banChatMember`, {
        chat_id: chatId,
        user_id: targetId
      });

      if (kickResponse.data.ok) {
        // UNBAN biar pure kick (bukan ban permanent)
        await axios.post(`https://api.telegram.org/bot${token}/unbanChatMember`, {
          chat_id: chatId,
          user_id: targetId,
          only_if_banned: false  // KICK + allow rejoin
        });
        
        await bot.sendMessage(chatId, `✅ User @${msg.reply_to_message.from.username || targetId} berhasil DIKICK 👢`, {
          reply_to_message_id: msg.message_id
        });
      }

    } catch (err) {
      console.error('KICK ERROR:', err.response?.data || err.message);
      
      const errorMsg = err.response?.data?.description || err.message;
      
      if (errorMsg.includes('400') || errorMsg.includes('CHAT_ADMIN_REQUIRED')) {
        bot.sendMessage(chatId, '❌ Bot harus admin + hak "Ban Users" ON!');
      } else if (errorMsg.includes('USER_ADMIN_INVALID')) {
        bot.sendMessage(chatId, '❌ Target admin, ga bisa dikick!');
      } else if (errorMsg.includes('not modified')) {
        bot.sendMessage(chatId, '✅ User udah ga di grup!');
      } else {
        bot.sendMessage(chatId, `❌ Error: ${errorMsg}`);
      }
    }
  });

  return {
    enable() {
      enabled = true;
      console.log("[PLUGIN] Kick DIRECT API diaktifkan");
    },
    disable() {
      enabled = false;
      console.log("[PLUGIN] Kick dimatikan");
    }
  };
};
