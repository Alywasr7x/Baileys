// PLUGIN/GETPP.js - 100% WORKING untuk custom.js
const axios = require('axios');
const fs = require('fs');
const path = require('path');

module.exports = (bot) => {
  let enabled = true;

  bot.onText(/\/(GETPP|getprofile)(?:@[\w]+)?$/, async (msg) => {
    if (!enabled) return;

    const chatId = msg.chat.id;

    try {
      // Target dari reply atau pengirim
      const targetMsg = msg.reply_to_message || msg;
      const user = targetMsg.from;
      const userId = user.id;

      // Status message
      const statusMsg = await bot.sendMessage(chatId, '⏳ Mengambil foto profil...');

      // Ambil profile photos
      const photos = await bot.getUserProfilePhotos(userId, { limit: 1 });
      
      if (photos.total_count === 0) {
        return bot.editMessageText('❌ User tidak punya foto profil.', {
          chat_id: chatId,
          message_id: statusMsg.message_id
        });
      }

      // Ambil file_id foto profil terbaru
      const fileId = photos.photos[0][0].file_id;
      
      // Ambil file info
      const file = await bot.getFile(fileId);
      const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;

      // Download foto profil
      const tempPath = path.join(__dirname, '../temp', `profile-${Date.now()}.jpg`);
      
      // Buat folder temp kalau belum ada
      const tempDir = path.join(__dirname, '../temp');
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }

      const writer = fs.createWriteStream(tempPath);
      const response = await axios({
        url: fileUrl,
        method: 'GET',
        responseType: 'stream'
      });

      return new Promise((resolve, reject) => {
        response.data.pipe(writer);

        writer.on('finish', async () => {
          try {
            // Kirim foto profil
            await bot.sendPhoto(chatId, tempPath, {
              caption: `✅ *Done ambil PP*\n👤 ${user.first_name || 'User'} (@${user.username || 'no username'})`,
              parse_mode: 'Markdown',
              reply_to_message_id: msg.message_id
            });

            // Hapus temp file & status
            setTimeout(() => {
              fs.unlinkSync(tempPath).catch(() => {});
              bot.deleteMessage(chatId, statusMsg.message_id).catch(() => {});
            }, 3000);

            resolve();
          } catch (err) {
            reject(err);
          }
        });

        writer.on('error', async (err) => {
          await bot.editMessageText('❌ Gagal download foto profil.', {
            chat_id: chatId,
            message_id: statusMsg.message_id
          });
          reject(err);
        });
      });

    } catch (err) {
      console.error('[GETPP ERROR]', err.message);
      bot.sendMessage(chatId, `❌ Error:\n\`${err.message}\``, { 
        parse_mode: 'Markdown',
        reply_to_message_id: msg.message_id 
      });
    }
  });

  return {
    enable() {
      enabled = true;
      console.log("[PLUGIN] GetPP diaktifkan");
    },
    disable() {
      enabled = false;
      console.log("[PLUGIN] GetPP dimatikan");
    }
  };
};
