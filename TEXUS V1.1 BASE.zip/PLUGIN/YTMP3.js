// PLUGIN/YTMP3.js - 100% WORKING untuk custom.js
const DY_SCRAP = require('@dark-yasiya/scrap');
const dy_scrap = new DY_SCRAP();

module.exports = (bot) => {
  let enabled = true;

  bot.onText(/\/YTMP3D(?:@[\w]+)?(?:\s+(.+))?/, async (msg, match) => {
    if (!enabled) return;

    const chatId = msg.chat.id;
    const url = match[1];

    // Validasi URL YouTube
    if (!url || (!url.includes('youtube.com') && !url.includes('youtu.be'))) {
      return bot.sendMessage(chatId, 
        '📌 Kirim link YouTube yang valid!\nContoh: /ytmp3d https://youtu.be/xxxx', 
        { parse_mode: 'Markdown' }
      );
    }

    const statusMsg = await bot.sendMessage(chatId, '⏳ Lagi ambil data dari YouTube bro, sabar ya...');

    try {
      // Scrap YouTube MP3
      const result = await dy_scrap.ytMp3(url);

      const { title, dl_url, thumb, duration, quality, filesize, channel } = result;

      const caption = `
🎵 *Title:* ${title}
👤 *Channel:* ${channel || '-'}
📦 *Quality:* ${quality || '-'}
🕒 *Duration:* ${duration || '-'}
💾 *Size:* ${filesize || '-'}
      `.trim();

      // Kirim thumbnail + info
      await bot.sendPhoto(chatId, thumb, {
        caption: caption,
        parse_mode: 'HTML',
        reply_to_message_id: statusMsg.message_id
      });

      // Kirim audio MP3
      await bot.sendAudio(chatId, dl_url, {
        title: title,
        performer: channel || 'YouTube MP3',
        reply_to_message_id: statusMsg.message_id
      });

      // Hapus status message
      await bot.deleteMessage(chatId, statusMsg.message_id);

    } catch (err) {
      console.error('[YTMP3 ERROR]', err.message);
      await bot.editMessageText(`❌ Gagal ambil data. Mungkin link-nya error atau video-nya dibatasi.`, {
        chat_id: chatId,
        message_id: statusMsg.message_id
      });
    }
  });

  return {
    enable() {
      enabled = true;
      console.log("[PLUGIN] YTMP3 Downloader diaktifkan");
    },
    disable() {
      enabled = false;
      console.log("[PLUGIN] YTMP3 dinonaktifkan");
    }
  };
};
