// Buat file PLUGIN/TOURL.js
const FormData = require('form-data');
const fetch = require('node-fetch');

module.exports = (bot) => {
  let enabled = true;

  bot.onText(/^(?:\/TOURL|\/upload)(?:@[\w]+)?$/, async (msg, match) => {
    if (!enabled) return;

    const chatId = msg.chat.id;
    const repliedMsg = msg.reply_to_message || msg;

    let fileId;
    if (repliedMsg.photo) {
      fileId = repliedMsg.photo[repliedMsg.photo.length - 1].file_id;
    } else if (repliedMsg.document) {
      fileId = repliedMsg.document.file_id;
    } else if (repliedMsg.video) {
      fileId = repliedMsg.video.file_id;
    } else if (repliedMsg.audio) {
      fileId = repliedMsg.audio.file_id;
    } else if (repliedMsg.sticker) {
      fileId = repliedMsg.sticker.file_id;
    } else {
      return bot.sendMessage(chatId, "❌ Balas atau kirim file dulu untuk di-upload ke URL.");
    }

    const statusMsg = await bot.sendMessage(chatId, "🔍 Mengambil file dari Telegram...");

    try {
      const file = await bot.getFile(fileId);
      const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
      
      const response = await fetch(fileUrl);
      if (!response.ok) throw new Error("Gagal mengunduh file dari Telegram.");
      const buffer = await response.buffer();

      await bot.sendMessage(chatId, "⬆️ Mengupload ke Catbox...");
      const catboxLink = await catboxUpload(buffer);

      const caption = `╭─ 「 UPLOAD SUCCESS 」\n📂 Size: ${buffer.length} Byte\n🐱 Catbox: ${catboxLink}\n╰───────────────`;
      
      await bot.editMessageText(caption, {
        chat_id: chatId,
        message_id: statusMsg.message_id,
        disable_web_page_preview: true
      });

    } catch (e) {
      await bot.editMessageText(`❌ Error: ${e.message || e}`, {
        chat_id: chatId,
        message_id: statusMsg.message_id
      });
    }
  });

  return {
    enable() {
      enabled = true;
      console.log("[PLUGIN] ToURL Catbox diaktifkan");
    },
    disable() {
      enabled = false;
      console.log("[PLUGIN] ToURL Catbox dinonaktifkan");
    }
  };
};

async function catboxUpload(buffer) {
  const form = new FormData();
  form.append("reqtype", "fileupload");
  form.append("fileToUpload", buffer, {
    filename: "file.bin",
    contentType: "application/octet-stream"
  });

  const res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: form
  });
  
  if (!res.ok) throw new Error("Gagal menghubungi Catbox.");
  return await res.text();
}
