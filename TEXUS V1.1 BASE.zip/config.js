module.exports = {
  BOT_TOKEN: "YOUR_TOKEN",
  OWNER_ID: ["ID_TELE"],
};